import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Pause, n as RotateCcw, r as Play } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DENQyX_C.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PAL = {
	paper: "#f4ebda",
	paperDeep: "#e7d8c0",
	desk: "#efe2cc",
	ink: "#2c261f",
	inkSoft: "#6d6256",
	faint: "#b5a690",
	skin: "#f0cbb4",
	skinDeep: "#e2b496",
	sunset: "#e07a4c",
	sun: "#f2b15a",
	blush: "#e7a394",
	leaf: "#7e9164",
	leafDeep: "#4e6844",
	sky: "#d7e6ee",
	dusk: "#f3c2a4",
	night: "#1b2436",
	nightMid: "#31425f",
	blue: "#6e92a6",
	blueDeep: "#3e6278",
	sea: "#3f6e82",
	gold: "#d7b57a",
	white: "#fffaf3",
	rose: "#c96b6b",
	jacket: "#c4785a",
	pants: "#4d463f",
	shirt: "#8fb4c6",
	wood: "#e4c89a"
};
var frameLive = 0;
function setFrameLive(t) {
	frameLive = t;
}
function clamp(v, a = 0, b = 1) {
	return Math.max(a, Math.min(b, v));
}
function lerp(a, b, t) {
	return a + (b - a) * t;
}
function smooth(t) {
	const x = clamp(t);
	return x * x * (3 - 2 * x);
}
function revealAt(local, delay, dur = .75) {
	return smooth((local - delay) / dur);
}
function qbez(a, b, c, n = 8) {
	const out = [];
	for (let i = 0; i <= n; i++) {
		const t = i / n;
		const u = 1 - t;
		out.push([u * u * a[0] + 2 * u * t * b[0] + t * t * c[0], u * u * a[1] + 2 * u * t * b[1] + t * t * c[1]]);
	}
	return out;
}
function stroke(ctx, pts, opt = {}) {
	const reveal = opt.reveal ?? 1;
	if (reveal <= .01 || pts.length < 2) return;
	const color = opt.color ?? PAL.ink;
	const width = opt.w ?? 2;
	const passes = opt.passes ?? 2;
	const seed = opt.seed ?? pts[0][0] * .013 + pts[0][1] * .017;
	const q = Math.floor(frameLive * 8);
	const boilX = Math.sin(q * 1.7 + seed * 3) * width * .16;
	const boilY = Math.cos(q * 1.3 + seed * 2) * width * .16;
	const maxSeg = (pts.length - 1) * reveal;
	ctx.save();
	ctx.lineCap = "round";
	ctx.lineJoin = "round";
	ctx.strokeStyle = color;
	ctx.globalAlpha = opt.a ?? 1;
	for (let p = 0; p < passes; p++) {
		ctx.lineWidth = width * (p === 0 ? 1 : .42);
		ctx.beginPath();
		const jx = Math.sin(seed * 4 + p * 2.1) * width * .22 + boilX;
		const jy = Math.cos(seed * 3 + p * 1.7) * width * .22 + boilY;
		let started = false;
		const last = Math.min(pts.length - 1, Math.ceil(maxSeg));
		for (let i = 0; i <= last; i++) {
			const wob = Math.sin(i * 1.7 + seed + p) * width * .16;
			let x = pts[i][0] + jx + wob;
			let y = pts[i][1] + jy + Math.cos(i * 1.3 + seed) * width * .14;
			if (i > 0 && i > maxSeg) {
				const f = clamp(maxSeg - (i - 1));
				const px = pts[i - 1][0] + jx;
				const py = pts[i - 1][1] + jy;
				x = px + (x - px) * f;
				y = py + (y - py) * f;
			}
			if (!started) {
				ctx.moveTo(x, y);
				started = true;
			} else ctx.lineTo(x, y);
			if (i > maxSeg) break;
		}
		ctx.stroke();
	}
	ctx.restore();
}
function fillPoly(ctx, pts, color, alpha = 1) {
	if (pts.length < 3 || alpha <= .01) return;
	ctx.save();
	ctx.globalAlpha = alpha;
	ctx.fillStyle = color;
	ctx.beginPath();
	ctx.moveTo(pts[0][0], pts[0][1]);
	for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
	ctx.closePath();
	ctx.fill();
	ctx.restore();
}
function blot(ctx, x, y, rx, ry, color, alpha = 1) {
	if (alpha <= .01 || rx <= 0 || ry <= 0) return;
	ctx.save();
	ctx.translate(x, y);
	const g = ctx.createRadialGradient(-rx * .15, -ry * .2, Math.min(rx, ry) * .08, 0, 0, Math.max(rx, ry));
	g.addColorStop(0, color);
	g.addColorStop(1, "rgba(0,0,0,0)");
	ctx.fillStyle = g;
	ctx.globalAlpha = alpha;
	ctx.beginPath();
	ctx.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
	ctx.fill();
	ctx.restore();
}
function oval(ctx, x, y, rx, ry, opt = {}) {
	const n = 16;
	const pts = [];
	for (let i = 0; i <= n; i++) {
		const a = i / n * Math.PI * 2;
		pts.push([x + Math.cos(a) * rx, y + Math.sin(a) * ry]);
	}
	stroke(ctx, pts, opt);
}
function frameRect(ctx, x, y, w, h, reveal, color = PAL.ink, lw = 2.2) {
	[
		[[x, y], [x + w, y]],
		[[x + w, y], [x + w, y + h]],
		[[x + w, y + h], [x, y + h]],
		[[x, y + h], [x, y]]
	].forEach((seg, i) => {
		stroke(ctx, seg, {
			w: lw,
			color,
			reveal: clamp(reveal * 4 - i),
			seed: i + x * .01
		});
	});
}
function brush(ctx, text, x, y, size, color, alpha = 1) {
	if (alpha <= .01 || !text) return;
	ctx.save();
	ctx.globalAlpha = alpha;
	ctx.fillStyle = color;
	ctx.font = `${size}px "Ma Shan Zheng", "WenQuanYi Zen Hei", serif`;
	ctx.textAlign = "center";
	ctx.textBaseline = "middle";
	ctx.fillText(text, x, y);
	ctx.restore();
}
var grain = null;
function paperGrain(ctx) {
	if (grain) return grain;
	const c = document.createElement("canvas");
	c.width = 180;
	c.height = 180;
	const g = c.getContext("2d");
	if (!g) return null;
	const img = g.createImageData(180, 180);
	for (let i = 0; i < img.data.length; i += 4) {
		const n = Math.random();
		img.data[i] = 70;
		img.data[i + 1] = 52;
		img.data[i + 2] = 34;
		img.data[i + 3] = n > .78 ? Math.floor((n - .78) * 220) : 0;
	}
	g.putImageData(img, 0, 0);
	grain = ctx.createPattern(c, "repeat");
	return grain;
}
function vignette(ctx, w, h) {
	const vg = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * .42, w / 2, h * .46, Math.max(w, h) * .72);
	vg.addColorStop(0, "rgba(0,0,0,0)");
	vg.addColorStop(1, "rgba(48,32,20,0.2)");
	ctx.fillStyle = vg;
	ctx.fillRect(0, 0, w, h);
}
function limb(ctx, a, b, c, width, color, reveal, seed) {
	stroke(ctx, qbez(a, b, c, 7), {
		w: width,
		color,
		reveal,
		passes: 1,
		seed
	});
}
function person(ctx, p) {
	const s = p.s ?? 1;
	const reveal = p.reveal ?? 1;
	if (reveal <= .02) return;
	const phase = p.phase ?? 0;
	const bob = p.pose === "walk" ? Math.sin(phase * 2) * 3 : Math.sin(phase * .6) * 1.2;
	const sit = p.pose === "sit";
	const hipY = sit ? -46 : -72;
	const neckY = hipY - 48;
	const headY = neckY - 28;
	const headR = 22;
	ctx.save();
	ctx.translate(p.x, p.y + bob * s);
	ctx.scale((p.flip ? -1 : 1) * s, s);
	ctx.globalAlpha = 1;
	blot(ctx, 2, 4, 34, 7, "rgba(70,50,30,0.45)", .28 * reveal);
	const sw = Math.sin(phase);
	const pants = p.pants ?? PAL.pants;
	const drawLeg = (side, seed) => {
		const hip = [side * 7, hipY];
		let foot;
		if (sit) foot = [side * 34, hipY + 6];
		else if (p.pose === "walk") {
			const lift = side === -1 ? sw > 0 ? -Math.abs(sw) * 8 : 0 : sw < 0 ? -Math.abs(sw) * 8 : 0;
			foot = [side * 12 + (side === -1 ? -sw : sw) * 16, lift];
		} else foot = [side * 14, 0];
		const knee = [(hip[0] + foot[0]) / 2 + side * 2, (hip[1] + foot[1]) / 2 - (sit ? 2 : 8)];
		if (!p.skirt) limb(ctx, hip, knee, foot, 9, pants, reveal, seed);
		limb(ctx, hip, knee, foot, 1.7, PAL.ink, reveal, seed + 3);
		blot(ctx, foot[0], foot[1] + 1, sit ? 7 : 9, 4, PAL.ink, reveal);
	};
	if (p.skirt) {
		const hem = hipY + 36;
		fillPoly(ctx, [
			[-18, hipY + 2],
			[18, hipY + 2],
			[28, hem],
			[-28, hem]
		], p.shirt, .95 * reveal);
		stroke(ctx, [
			[-18, hipY + 2],
			[-28, hem],
			[28, hem],
			[18, hipY + 2]
		], {
			w: 1.7,
			reveal,
			seed: 9
		});
	} else {
		drawLeg(-1, 1);
		drawLeg(1, 2);
	}
	const torso = [
		[-24, hipY + 4],
		[-28, neckY + 6],
		[-12, neckY - 6],
		[12, neckY - 6],
		[26, neckY + 6],
		[22, hipY + 4]
	];
	fillPoly(ctx, torso, p.shirt, .94 * reveal);
	stroke(ctx, [...torso, torso[0]], {
		w: 1.8,
		reveal,
		seed: 4
	});
	stroke(ctx, [
		[0, neckY - 2],
		[-6, neckY + 14],
		[6, neckY + 14]
	], {
		w: 1.3,
		color: PAL.inkSoft,
		reveal,
		seed: 5,
		a: .7
	});
	const arm = (side) => {
		const shoulder = [side * 18, neckY + 8];
		let elbow;
		let hand;
		const swing = Math.sin(phase + (side < 0 ? 0 : Math.PI));
		if (p.pose === "walk") {
			hand = [side * 14 + swing * 12, hipY + 8];
			elbow = [side * 24 + swing * 4, (shoulder[1] + hand[1]) / 2];
		} else if (p.pose === "reach" && side > 0) {
			elbow = [36, neckY];
			hand = [64, neckY - 16];
		} else if (p.pose === "wave" && side > 0) {
			elbow = [30, neckY - 18];
			hand = [34, neckY - 50];
		} else if (p.pose === "hug") {
			elbow = [side * 28, neckY + 2];
			hand = [34, neckY + 8];
		} else if (p.pose === "pray") {
			elbow = [side * 12, neckY + 18];
			hand = [side * 3, neckY + 10];
		} else if (p.pose === "apart") {
			elbow = [side * 20, hipY + 6];
			hand = [side * 12, hipY + 20];
		} else if (sit) {
			elbow = [side * 24, hipY + 10];
			hand = [side * 32, hipY + 22];
		} else {
			elbow = [side * 26, hipY + 4];
			hand = [side * 18, hipY + 24];
		}
		limb(ctx, shoulder, elbow, hand, 8, p.shirt, reveal, 10 + side);
		limb(ctx, shoulder, elbow, hand, 1.5, PAL.ink, reveal, 12 + side);
		blot(ctx, hand[0], hand[1], 5.5, 4.5, PAL.skin, reveal);
	};
	arm(-1);
	arm(1);
	if (p.hair === "long") fillPoly(ctx, [
		[-20, headY - 4],
		[-26, headY + 20],
		[-22, hipY + 8],
		[22, hipY + 6],
		[26, headY + 18],
		[20, headY - 4]
	], "#3a3128", reveal);
	blot(ctx, 0, headY, 23, 24, PAL.skin, reveal);
	oval(ctx, 0, headY, headR, 23, {
		w: 1.8,
		reveal,
		seed: 20
	});
	if (p.hair === "short") {
		fillPoly(ctx, [
			[-21, headY - 2],
			[-23, headY - 14],
			[-8, headY - headR - 4],
			[10, headY - headR - 2],
			[24, headY - 12],
			[headR, headY + 2],
			[6, headY - 4],
			[-4, headY + 1]
		], "#3a3128", reveal);
		stroke(ctx, qbez([-20, headY], [-6, headY - headR - 6], [headR, headY - 2], 8), {
			w: 1.6,
			reveal,
			seed: 21
		});
	} else {
		stroke(ctx, qbez([-16, headY - 6], [0, headY - 2], [14, headY - 8], 6), {
			w: 1.5,
			reveal,
			seed: 22,
			a: .85
		});
		stroke(ctx, qbez([-18, headY - 8], [-24, headY + 16], [-16, hipY], 6), {
			w: 1.4,
			reveal,
			seed: 23
		});
		stroke(ctx, qbez([16, headY - 6], [24, headY + 18], [14, hipY - 4], 6), {
			w: 1.4,
			reveal,
			seed: 24
		});
		if (p.ribbon) {
			blot(ctx, 18, headY - 8, 6, 5, p.ribbon, reveal);
			stroke(ctx, qbez([18, headY - 4], [26, headY + 6], [20, headY + 16], 4), {
				w: 1.4,
				color: p.ribbon,
				reveal,
				seed: 25
			});
		}
	}
	const eye = (x, sad) => {
		const y = headY - 1;
		if (p.mood === "sleep") {
			stroke(ctx, [[x - 5, y], [x + 4, y + 1]], {
				w: 1.5,
				reveal,
				seed: x
			});
			return;
		}
		if (p.mood === "smile") {
			stroke(ctx, qbez([x - 5, y + 1], [x, y - 3], [x + 5, y + 1], 4), {
				w: 1.5,
				reveal,
				seed: x
			});
			return;
		}
		blot(ctx, x, y + (p.mood === "shy" ? 2 : 0), 1.7, 1.7, PAL.ink, reveal);
		if (sad || p.mood === "sad") stroke(ctx, [[x - 5, y - 6], [x + 4, y - 4]], {
			w: 1.3,
			reveal,
			seed: x + 2
		});
	};
	eye(-7, p.mood === "sad");
	eye(7, p.mood === "sad");
	if (p.mood === "smile" || p.mood === "shy") {
		blot(ctx, -12, headY + 6, 5, 3, PAL.blush, .55 * reveal);
		blot(ctx, 12, headY + 6, 5, 3, PAL.blush, .55 * reveal);
	}
	if (p.mood === "sad") {
		const drip = 4 + Math.sin(phase) * 1.5;
		stroke(ctx, [[8, headY + 6], [9, headY + 6 + drip]], {
			w: 1.3,
			color: PAL.blue,
			reveal,
			seed: 30
		});
	}
	const my = headY + 10;
	if (p.mood === "smile") stroke(ctx, qbez([-5, my], [0, my + 5], [6, my], 4), {
		w: 1.4,
		reveal,
		seed: 31
	});
	else if (p.mood === "sad") stroke(ctx, qbez([-5, my + 3], [0, my - 1], [5, my + 3], 4), {
		w: 1.4,
		reveal,
		seed: 32
	});
	else if (p.mood !== "sleep") stroke(ctx, [[-3, my], [4, my + 1]], {
		w: 1.3,
		reveal,
		seed: 33
	});
	ctx.restore();
}
function heart(ctx, x, y, s, color, reveal = 1) {
	if (reveal <= .02) return;
	const pts = [];
	for (let i = 0; i <= 28; i++) {
		const t = i / 28 * Math.PI * 2;
		const hx = 16 * Math.sin(t) ** 3;
		const hy = -(13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t));
		pts.push([x + hx * s, y + hy * s]);
	}
	fillPoly(ctx, pts, color, .92 * reveal);
	stroke(ctx, pts, {
		w: 1.4,
		reveal,
		seed: 40,
		a: .75
	});
}
function bird(ctx, x, y, s, flap, reveal = 1, fly = 0) {
	if (reveal <= .02) return;
	ctx.save();
	ctx.translate(x, y);
	ctx.rotate(fly);
	ctx.scale(s, s);
	const wing = Math.sin(flap) * 14;
	stroke(ctx, qbez([-18, 2], [-26, -8 - wing], [-6, -2], 5), {
		w: 1.7,
		reveal,
		seed: 50
	});
	stroke(ctx, qbez([6, -2], [20, -10 - wing], [16, 3], 5), {
		w: 1.7,
		reveal,
		seed: 51
	});
	fillPoly(ctx, [
		[-8, -4],
		[8, -6],
		[12, 0],
		[4, 6],
		[-10, 5]
	], PAL.ink, reveal);
	stroke(ctx, qbez([-12, 2], [-20, 8], [-16, 0], 4), {
		w: 1.5,
		reveal,
		seed: 52
	});
	blot(ctx, 10, -2, 2, 2, PAL.sun, reveal);
	stroke(ctx, [[10, 0], [16, 1]], {
		w: 1.4,
		color: PAL.sunset,
		reveal,
		seed: 53
	});
	ctx.restore();
}
function leaf(ctx, x, y, s, rot, reveal = 1) {
	ctx.save();
	ctx.translate(x, y);
	ctx.rotate(rot);
	ctx.scale(s, s);
	const pts = qbez([-8, 2], [0, -14], [10, 0], 6).concat(qbez([10, 0], [0, 8], [-8, 2], 5));
	fillPoly(ctx, pts, PAL.leaf, .85 * reveal);
	stroke(ctx, pts, {
		w: 1.1,
		color: PAL.leafDeep,
		reveal,
		seed: x
	});
	ctx.restore();
}
function flower(ctx, x, y, s, open, color) {
	const o = Math.max(.05, open);
	for (let i = 0; i < 5; i++) {
		const a = i / 5 * Math.PI * 2 + .4;
		blot(ctx, x + Math.cos(a) * 7 * s * o, y + Math.sin(a) * 7 * s * o, 5.5 * s, 8 * s, color, .75);
	}
	blot(ctx, x, y, 3.2 * s, 3.2 * s, PAL.sun, .95);
	stroke(ctx, [[x, y + 6 * s], [x, y + 22 * s]], {
		w: 1.3,
		color: PAL.leafDeep,
		reveal: open,
		seed: y
	});
}
function pot(ctx, x, y, growth, reveal = 1) {
	if (reveal <= .02) return;
	fillPoly(ctx, [
		[-18, -8],
		[18, -8],
		[14, 16],
		[-14, 16]
	].map(([px, py]) => [x + px, y + py]), PAL.sunset, .85 * reveal);
	stroke(ctx, [
		[x - 18, y - 8],
		[x + 18, y - 8],
		[x + 14, y + 16],
		[x - 14, y + 16],
		[x - 18, y - 8]
	], {
		w: 1.6,
		reveal,
		seed: 60
	});
	const g = Math.max(0, growth);
	stroke(ctx, [[x, y - 8], [x + 2, y - 8 - 36 * g]], {
		w: 1.6,
		color: PAL.leafDeep,
		reveal,
		seed: 61
	});
	leaf(ctx, x - 10 * g, y - 20 - 10 * g, .8, -.8, reveal * g);
	leaf(ctx, x + 12 * g, y - 28 * g, .85, .6, reveal * g);
	if (g > .65) {
		blot(ctx, x + 2, y - 8 - 40 * g, 5, 5, PAL.sun, reveal);
		heart(ctx, x + 16, y - 46 * g, .28, PAL.gold, reveal * (g - .4));
	}
}
function starShape(ctx, x, y, r, color, reveal = 1) {
	if (reveal <= .02) return;
	const pts = [];
	for (let i = 0; i < 10; i++) {
		const a = i / 10 * Math.PI * 2 - Math.PI / 2;
		const rad = i % 2 === 0 ? r : r * .42;
		pts.push([x + Math.cos(a) * rad, y + Math.sin(a) * rad]);
	}
	fillPoly(ctx, pts, color, .9 * reveal);
	stroke(ctx, [...pts, pts[0]], {
		w: 1.1,
		reveal,
		seed: x,
		a: .65
	});
}
function moon(ctx, x, y, r, reveal = 1) {
	if (reveal <= .02) return;
	blot(ctx, x, y, r * 1.15, r * 1.15, "rgba(244,235,218,0.45)", .55 * reveal);
	ctx.save();
	ctx.fillStyle = "#f7f1e4";
	ctx.globalAlpha = reveal;
	ctx.beginPath();
	ctx.arc(x, y, r, 0, Math.PI * 2);
	ctx.fill();
	ctx.globalAlpha = .45 * reveal;
	ctx.fillStyle = "#e7dcc4";
	ctx.beginPath();
	ctx.arc(x - r * .25, y - r * .1, r * .22, 0, Math.PI * 2);
	ctx.fill();
	ctx.beginPath();
	ctx.arc(x + r * .28, y + r * .22, r * .14, 0, Math.PI * 2);
	ctx.fill();
	ctx.restore();
	oval(ctx, x, y, r, r, {
		w: 1.6,
		color: PAL.inkSoft,
		reveal,
		a: .45,
		seed: 70
	});
}
function sun(ctx, x, y, r, reveal = 1) {
	blot(ctx, x, y, r * 1.8, r * 1.5, PAL.sun, .55 * reveal);
	ctx.save();
	ctx.globalAlpha = reveal;
	ctx.fillStyle = "#f6c56a";
	ctx.beginPath();
	ctx.arc(x, y, r, 0, Math.PI * 2);
	ctx.fill();
	ctx.restore();
	for (let i = 0; i < 10; i++) {
		const a = i / 10 * Math.PI * 2;
		stroke(ctx, [[x + Math.cos(a) * (r + 6), y + Math.sin(a) * (r + 6)], [x + Math.cos(a) * (r + 18), y + Math.sin(a) * (r + 16)]], {
			w: 1.6,
			color: PAL.sunset,
			reveal,
			seed: i,
			a: .8
		});
	}
}
function rain(ctx, w, h, live, ground, amount = 1) {
	const count = Math.floor(64 * amount);
	for (let i = 0; i < count; i++) {
		const x = i * 97 % (w + 60) - 30;
		const speed = 240 + i % 6 * 36;
		const y0 = (i * 53 + live * speed) % (ground + 50) - 40;
		const len = 12 + i % 5 * 3;
		stroke(ctx, [[x, y0], [x - 5, y0 + len]], {
			w: 1.15,
			color: PAL.blueDeep,
			a: .32,
			passes: 1,
			seed: i
		});
	}
}
function fallingLeaves(ctx, w, ground, live, n = 16) {
	for (let i = 0; i < n; i++) leaf(ctx, (i * 131 + live * (18 + i % 5 * 6)) % (w + 40) - 20, (i * 77 + live * (26 + i % 4 * 8)) % (ground + 30) - 16, .55 + i % 3 * .15, live * .8 + i, 1);
}
function crowd(ctx, w, gy, live, reveal = 1) {
	for (let i = 0; i < 8; i++) {
		const x = (i * 140 - live * 18) % (w + 80) - 40;
		const h = 46 + i % 3 * 10;
		ctx.save();
		ctx.globalAlpha = .28 * reveal;
		ctx.fillStyle = PAL.ink;
		ctx.beginPath();
		ctx.ellipse(x, gy - h - 8, 7, 8, 0, 0, Math.PI * 2);
		ctx.fill();
		ctx.fillRect(x - 8, gy - h, 16, h);
		ctx.restore();
	}
}
function pencilTool(ctx, x, y, angle, reveal = 1) {
	if (reveal <= .02) return;
	ctx.save();
	ctx.translate(x, y);
	ctx.rotate(angle);
	ctx.globalAlpha = reveal;
	ctx.fillStyle = PAL.gold;
	ctx.fillRect(-5, -46, 10, 64);
	ctx.fillStyle = PAL.ink;
	ctx.beginPath();
	ctx.moveTo(-5, -46);
	ctx.lineTo(0, -62);
	ctx.lineTo(5, -46);
	ctx.fill();
	ctx.fillStyle = "#3a342c";
	ctx.beginPath();
	ctx.moveTo(-2, -56);
	ctx.lineTo(0, -62);
	ctx.lineTo(2, -56);
	ctx.fill();
	ctx.restore();
}
function polaroid(ctx, x, y, rot, sc, reveal, draw) {
	if (reveal <= .02) return;
	ctx.save();
	ctx.translate(x, y);
	ctx.rotate(rot);
	ctx.scale(sc, sc);
	ctx.globalAlpha = reveal;
	ctx.fillStyle = PAL.white;
	ctx.fillRect(-46, -58, 92, 112);
	ctx.strokeStyle = PAL.inkSoft;
	ctx.lineWidth = 1.2;
	ctx.strokeRect(-46, -58, 92, 112);
	ctx.beginPath();
	ctx.rect(-40, -52, 80, 68);
	ctx.clip();
	ctx.globalAlpha = 1;
	draw();
	ctx.restore();
}
function clock(ctx, x, y, r, live, reveal = 1) {
	oval(ctx, x, y, r, r, {
		w: 1.7,
		reveal,
		seed: 80
	});
	blot(ctx, x, y, 2, 2, PAL.ink, reveal);
	const hour = live * .45;
	const min = live * 2.4;
	stroke(ctx, [[x, y], [x + Math.sin(hour) * r * .45, y - Math.cos(hour) * r * .45]], {
		w: 1.8,
		reveal,
		seed: 81
	});
	stroke(ctx, [[x, y], [x + Math.sin(min) * r * .72, y - Math.cos(min) * r * .72]], {
		w: 1.3,
		reveal,
		seed: 82
	});
}
function openPalm(ctx, x, y, s, reveal = 1) {
	if (reveal <= .02) return;
	ctx.save();
	ctx.translate(x, y);
	ctx.scale(s, s);
	blot(ctx, 0, 8, 48, 34, PAL.skin, .95 * reveal);
	oval(ctx, 0, 10, 46, 32, {
		w: 1.8,
		reveal,
		seed: 90
	});
	[
		-30,
		-12,
		6,
		24
	].forEach((fx, i) => {
		limb(ctx, [fx, -8], [fx + 2, -40], [fx - 2, -68 - (i === 2 ? 6 : 0)], 7, PAL.skin, reveal, 91 + i);
		limb(ctx, [fx, -8], [fx + 2, -40], [fx - 2, -68 - (i === 2 ? 6 : 0)], 1.4, PAL.ink, reveal, 95 + i);
	});
	limb(ctx, [36, 10], [58, -8], [52, -36], 7, PAL.skin, reveal, 100);
	limb(ctx, [36, 10], [58, -8], [52, -36], 1.4, PAL.ink, reveal, 101);
	ctx.restore();
}
function umbrella(ctx, x, y, s, color, reveal = 1) {
	if (reveal <= .02) return;
	ctx.save();
	ctx.translate(x, y);
	ctx.scale(s, s);
	blot(ctx, 0, -4, 70, 28, color, .55 * reveal);
	stroke(ctx, qbez([-74, 0], [0, -46], [74, 0], 10), {
		w: 2,
		reveal,
		seed: 110
	});
	stroke(ctx, [[-74, 0], [74, 0]], {
		w: 1.6,
		reveal,
		seed: 111
	});
	stroke(ctx, [[0, 0], [0, 78]], {
		w: 1.8,
		reveal,
		seed: 112
	});
	stroke(ctx, qbez([0, 78], [10, 86], [0, 92], 4), {
		w: 1.6,
		reveal,
		seed: 113
	});
	for (let i = -2; i <= 2; i++) stroke(ctx, [[i * 24, 0], [i * 16, -22]], {
		w: 1.1,
		color: PAL.inkSoft,
		reveal,
		a: .6,
		seed: 114 + i
	});
	ctx.restore();
}
function kite(ctx, x, y, s, reveal = 1) {
	if (reveal <= .02) return;
	ctx.save();
	ctx.translate(x, y);
	ctx.scale(s, s);
	fillPoly(ctx, [
		[0, -28],
		[20, 0],
		[0, 32],
		[-20, 0]
	], PAL.sunset, .85 * reveal);
	stroke(ctx, [
		[0, -28],
		[20, 0],
		[0, 32],
		[-20, 0],
		[0, -28]
	], {
		w: 1.4,
		reveal,
		seed: 120
	});
	stroke(ctx, [[0, -28], [0, 32]], {
		w: 1,
		color: PAL.inkSoft,
		reveal,
		seed: 121
	});
	stroke(ctx, qbez([0, 32], [6, 48], [-2, 64], 4), {
		w: 1.2,
		reveal,
		seed: 122
	});
	blot(ctx, 4, 52, 4, 3, PAL.gold, reveal);
	blot(ctx, -3, 62, 3, 2.4, PAL.blue, reveal);
	ctx.restore();
}
function ghost(ctx, x, y, s, reveal = 1) {
	if (reveal <= .02) return;
	ctx.save();
	ctx.translate(x, y);
	ctx.scale(s, s);
	fillPoly(ctx, [
		[-18, -10],
		[-16, -28],
		[0, -36],
		[16, -28],
		[18, -8],
		[12, 8],
		[6, -2],
		[0, 10],
		[-6, -2],
		[-12, 8]
	], PAL.white, .95 * reveal);
	stroke(ctx, qbez([-18, -6], [0, -40], [18, -6], 8).concat([
		[12, 8],
		[4, -2],
		[-2, 10],
		[-14, 4]
	]), {
		w: 1.5,
		reveal,
		seed: 130
	});
	blot(ctx, -6, -16, 2, 2, PAL.ink, reveal);
	blot(ctx, 6, -16, 2, 2.4, PAL.ink, reveal);
	blot(ctx, -8, -8, 4, 2.5, PAL.blush, .6 * reveal);
	blot(ctx, 8, -8, 4, 2.5, PAL.blush, .6 * reveal);
	ctx.restore();
}
function bug(ctx, x, y, s, reveal = 1) {
	ctx.save();
	ctx.translate(x, y);
	ctx.scale(s, s);
	fillPoly(ctx, [
		[-10, 0],
		[0, -6],
		[12, 0],
		[0, 6]
	], PAL.leaf, reveal);
	stroke(ctx, qbez([-12, 0], [0, -8], [14, 0], 5), {
		w: 1.2,
		color: PAL.leafDeep,
		reveal,
		seed: 140
	});
	blot(ctx, 12, -1, 3, 3, PAL.ink, reveal);
	stroke(ctx, [[-2, -4], [-8, -12]], {
		w: 1,
		reveal,
		seed: 141
	});
	stroke(ctx, [[2, -4], [6, -12]], {
		w: 1,
		reveal,
		seed: 142
	});
	ctx.restore();
}
function letter(ctx, x, y, w, h, reveal = 1) {
	if (reveal <= .02) return;
	ctx.save();
	ctx.translate(x, y);
	ctx.fillStyle = PAL.white;
	ctx.globalAlpha = reveal;
	ctx.fillRect(-w / 2, -h / 2, w, h);
	ctx.restore();
	frameRect(ctx, x - w / 2, y - h / 2, w, h, reveal, PAL.inkSoft, 1.4);
	stroke(ctx, [
		[x - w / 2, y - h / 2],
		[x, y],
		[x + w / 2, y - h / 2]
	], {
		w: 1.2,
		color: PAL.inkSoft,
		reveal,
		seed: 150
	});
	heart(ctx, x, y + h * .18, .28, PAL.rose, reveal);
}
function phone(ctx, x, y, s, missed, reveal = 1) {
	ctx.save();
	ctx.translate(x, y);
	ctx.scale(s, s);
	ctx.globalAlpha = reveal;
	ctx.fillStyle = PAL.ink;
	roundBox(ctx, -10, -18, 20, 36, 3);
	ctx.fillStyle = missed ? "#d7e4ea" : "#243044";
	ctx.fillRect(-7, -14, 14, 24);
	ctx.restore();
	if (missed) stroke(ctx, qbez([x + 8 * s, y - 8 * s], [x + 16 * s, y - 16 * s], [x + 8 * s, y - 22 * s], 4), {
		w: 1.3,
		color: PAL.rose,
		reveal,
		seed: 160
	});
}
function roundBox(ctx, x, y, w, h, r) {
	ctx.beginPath();
	ctx.moveTo(x + r, y);
	ctx.arcTo(x + w, y, x + w, y + h, r);
	ctx.arcTo(x + w, y + h, x, y + h, r);
	ctx.arcTo(x, y + h, x, y, r);
	ctx.arcTo(x, y, x + w, y, r);
	ctx.closePath();
	ctx.fill();
}
function tv(ctx, x, y, s, live, reveal = 1) {
	ctx.save();
	ctx.translate(x, y);
	ctx.scale(s, s);
	ctx.globalAlpha = reveal;
	ctx.fillStyle = "#3a342c";
	ctx.fillRect(-46, -32, 92, 58);
	ctx.globalAlpha = reveal * (.7 + (.35 + Math.sin(live * 7) * .08));
	ctx.fillStyle = "#f2d7a2";
	ctx.fillRect(-40, -26, 80, 46);
	ctx.restore();
	blot(ctx, x, y - 4 * s, 50 * s, 24 * s, PAL.sun, .18 * reveal);
}
function blocks(ctx, x, y, reveal = 1) {
	[
		{
			dx: -28,
			h: 16,
			c: PAL.sunset
		},
		{
			dx: -8,
			h: 28,
			c: PAL.blue
		},
		{
			dx: 12,
			h: 20,
			c: PAL.gold
		},
		{
			dx: 30,
			h: 12,
			c: PAL.leaf
		}
	].forEach((b, i) => {
		const rv = Math.max(0, reveal * 4 - i);
		ctx.save();
		ctx.globalAlpha = Math.min(1, rv);
		ctx.fillStyle = b.c;
		ctx.fillRect(x + b.dx, y - b.h, 16, b.h);
		ctx.restore();
		frameRect(ctx, x + b.dx, y - b.h, 16, b.h, Math.min(1, rv), PAL.ink, 1.2);
	});
}
function firework(ctx, x, y, live, born, color) {
	const age = live - born;
	if (age < 0 || age > 1.7) return;
	const u = age / 1.7;
	const n = 22;
	for (let i = 0; i < n; i++) {
		const a = i / n * Math.PI * 2 + i * .2;
		const dist = u * (54 + i % 4 * 10);
		const px = x + Math.cos(a) * dist;
		const py = y + Math.sin(a) * dist + u * u * 26;
		stroke(ctx, [[px, py], [px - Math.cos(a) * 7, py - Math.sin(a) * 7 + 2]], {
			w: 1.5,
			color,
			a: (1 - u) * (1 - u),
			passes: 1,
			seed: i
		});
	}
}
function scrap(ctx, x, y, size, rot, reveal, tint, mark) {
	if (reveal <= .02) return;
	ctx.save();
	ctx.translate(x, y);
	ctx.rotate(rot);
	ctx.globalAlpha = reveal;
	ctx.fillStyle = PAL.white;
	const s = size / 2;
	ctx.beginPath();
	ctx.moveTo(-s, -s);
	ctx.lineTo(s * .35, -s);
	ctx.arc(s * .35, -s + s * .28, s * .28, -Math.PI / 2, Math.PI / 2, true);
	ctx.lineTo(s, -s + s * .55);
	ctx.lineTo(s, s);
	ctx.lineTo(-s, s);
	ctx.closePath();
	ctx.fill();
	ctx.save();
	ctx.clip();
	ctx.globalAlpha = .45 * reveal;
	ctx.fillStyle = tint;
	ctx.fillRect(-s, -s, size, size);
	ctx.globalAlpha = 1;
	mark(ctx, s);
	ctx.restore();
	ctx.globalAlpha = reveal;
	ctx.strokeStyle = PAL.inkSoft;
	ctx.lineWidth = 1.3;
	ctx.stroke();
	ctx.restore();
}
function paperFlower(ctx, x, y, s, open) {
	ctx.save();
	ctx.translate(x, y);
	const petals = 6;
	for (let i = 0; i < petals; i++) {
		ctx.save();
		ctx.rotate(i / petals * Math.PI * 2);
		ctx.scale(s, s);
		const len = 8 + open * 18;
		fillPoly(ctx, [
			[0, 0],
			[-6, -len * .6],
			[0, -len],
			[6, -len * .6]
		], i % 2 ? PAL.blush : PAL.white, .9);
		stroke(ctx, [
			[0, 0],
			[-6, -len * .6],
			[0, -len],
			[6, -len * .6],
			[0, 0]
		], {
			w: 1.1,
			seed: i
		});
		ctx.restore();
	}
	blot(ctx, 0, 0, 4 * s, 4 * s, PAL.sun, 1);
	ctx.restore();
}
function bow(ctx, x, y, s, reveal = 1) {
	if (reveal <= .02) return;
	ctx.save();
	ctx.translate(x, y);
	ctx.scale(s, s);
	fillPoly(ctx, [
		[0, 0],
		[-18, -12],
		[-28, 0],
		[-16, 10]
	], PAL.rose, reveal);
	fillPoly(ctx, [
		[0, 0],
		[18, -12],
		[28, 0],
		[16, 10]
	], PAL.rose, reveal);
	blot(ctx, 0, 1, 5, 4, PAL.rose, reveal);
	stroke(ctx, [[-8, 6], [-14, 22]], {
		w: 1.5,
		color: PAL.rose,
		reveal,
		seed: 170
	});
	stroke(ctx, [[8, 6], [14, 22]], {
		w: 1.5,
		color: PAL.rose,
		reveal,
		seed: 171
	});
	ctx.restore();
}
function hills(ctx, w, h, base, layers) {
	for (const L of layers) {
		const pts = [[-30, h + 20]];
		for (let x = -30; x <= w + 30; x += 28) pts.push([x, L.y + Math.sin(x * .007 + L.seed) * L.amp + Math.sin(x * .018 + L.seed * 2) * L.amp * .35]);
		pts.push([w + 30, h + 20]);
		fillPoly(ctx, pts, L.color, 1);
		stroke(ctx, pts.slice(1, -1), {
			w: 1.4,
			color: PAL.inkSoft,
			a: .35,
			seed: L.seed,
			passes: 1
		});
	}
}
var CUES = [
	{
		id: "intro",
		t0: 0,
		name: "前奏"
	},
	{
		id: "keepsake",
		t0: 27.48,
		name: "收集",
		tone: "day"
	},
	{
		id: "stars",
		t0: 54.87,
		name: "星空"
	},
	{
		id: "street",
		t0: 65.25,
		name: "人海"
	},
	{
		id: "knowyou",
		t0: 79.14,
		name: "关于你"
	},
	{
		id: "dawn",
		t0: 95.68,
		name: "黎明"
	},
	{
		id: "keepsake",
		t0: 102.7,
		name: "回忆",
		tone: "dawn"
	},
	{
		id: "rain",
		t0: 139.2,
		name: "雨后"
	},
	{
		id: "days",
		t0: 151.09,
		name: "日常"
	},
	{
		id: "rift",
		t0: 163.49,
		name: "裂缝"
	},
	{
		id: "spark",
		t0: 174.99,
		name: "烟花"
	},
	{
		id: "keepsake",
		t0: 186.38,
		name: "回忆",
		tone: "dusk"
	},
	{
		id: "grow",
		t0: 209.87,
		name: "长大"
	},
	{
		id: "moon",
		t0: 241.28,
		name: "月亮"
	},
	{
		id: "keepsake",
		t0: 267.2,
		name: "回忆",
		tone: "night"
	},
	{
		id: "pieces",
		t0: 291.32,
		name: "拼好"
	},
	{
		id: "coda",
		t0: 339.32,
		name: "给你"
	}
];
function chapterAt(t) {
	let name = CUES[0].name;
	for (const c of CUES) if (c.t0 <= t) name = c.name;
	return name;
}
function groundY(h) {
	const raw = Math.min(h * .7, h - 64);
	return Math.max(h * .42, Math.min(raw, h * .78));
}
function peopleScale(h, gy) {
	return Math.min(1.12, Math.max(.48, (gy - 8) / 210));
}
function overscan(ctx, w, h, painter) {
	const g = ctx.createLinearGradient(0, 0, 0, h);
	painter(g);
	ctx.fillStyle = g;
	ctx.fillRect(-50, -50, w + 100, h + 100);
}
function floor(ctx, w, h, gy, color) {
	ctx.fillStyle = color;
	ctx.fillRect(-40, gy, w + 80, h - gy + 40);
	stroke(ctx, [
		[-20, gy],
		[w * .3, gy + 2],
		[w * .7, gy - 1],
		[w + 20, gy + 2]
	], {
		w: 1.6,
		color: PAL.inkSoft,
		a: .45,
		seed: 3
	});
}
function stars(ctx, w, horizon, live, n = 36) {
	for (let i = 0; i < n; i++) {
		const x = i * 137 % w;
		const y = i * 89 % Math.max(20, horizon * .86);
		const tw = .35 + Math.sin(live * 2 + i) * .35;
		if (i % 7 === 0) starShape(ctx, x, y, 4 + i % 3, PAL.gold, tw);
		else {
			ctx.save();
			ctx.globalAlpha = tw;
			ctx.fillStyle = "#f4ebda";
			ctx.fillRect(x, y, 1.6, 1.6);
			ctx.restore();
		}
	}
}
function margin(ctx, h) {
	ctx.save();
	ctx.strokeStyle = "rgba(201,107,107,0.35)";
	ctx.lineWidth = 1;
	ctx.beginPath();
	ctx.moveTo(28, 0);
	ctx.lineTo(28, h);
	ctx.stroke();
	ctx.restore();
}
function windowFrame(ctx, x, y, w, h, reveal) {
	frameRect(ctx, x, y, w, h, reveal, PAL.ink, 2.4);
	const mull = clamp(reveal * 2 - 1);
	stroke(ctx, [[x + w / 2, y], [x + w / 2, y + h]], {
		w: 1.8,
		reveal: mull,
		seed: 8
	});
	stroke(ctx, [[x, y + h * .42], [x + w, y + h * .42]], {
		w: 1.8,
		reveal: mull,
		seed: 9
	});
}
function photoInner(ctx, kind) {
	if (kind === 0) {
		ctx.fillStyle = "#d5e4ee";
		ctx.fillRect(-40, -52, 80, 68);
		rain(ctx, 80, 68, 2, 60, .4);
	} else if (kind === 1) {
		ctx.fillStyle = "#f6e7c8";
		ctx.fillRect(-40, -52, 80, 68);
		bird(ctx, 0, 8, 1.3, 1, 1);
	} else if (kind === 2) {
		ctx.fillStyle = "#f3d2b0";
		ctx.fillRect(-40, -52, 80, 68);
		sun(ctx, 18, -20, 10, 1);
	} else if (kind === 3) {
		ctx.fillStyle = "#e7f0ea";
		ctx.fillRect(-40, -52, 80, 68);
		heart(ctx, 0, -8, 1.1, PAL.rose, 1);
	} else {
		ctx.fillStyle = "#243044";
		ctx.fillRect(-40, -52, 80, 68);
		moon(ctx, 8, -10, 14, 1);
	}
}
function intro(f) {
	const { ctx, w, h, live, local, poster } = f;
	overscan(ctx, w, h, (g) => {
		g.addColorStop(0, "#f7f1e6");
		g.addColorStop(1, PAL.paper);
	});
	margin(ctx, h);
	const ww = Math.min(w * .42, 380);
	const wh = ww * .68;
	const x = w / 2 - ww / 2;
	const y = h * .1;
	const rv = revealAt(local, .6, 7);
	ctx.fillStyle = "#e7eef2";
	ctx.globalAlpha = clamp(rv);
	ctx.fillRect(x, y, ww, wh);
	ctx.globalAlpha = 1;
	windowFrame(ctx, x, y, ww, wh, rv);
	if (local > 6) rain(ctx, w, y + wh, live, y + wh, clamp((local - 6) / 4));
	const pr = revealAt(local, 8, 2);
	person(ctx, {
		x: w / 2 - ww * .12,
		y: y + wh * .78,
		s: peopleScale(h, h) * .38,
		hair: "short",
		shirt: PAL.jacket,
		mood: "soft",
		pose: "stand",
		phase: live,
		reveal: pr
	});
	person(ctx, {
		x: w / 2 + ww * .12,
		y: y + wh * .78,
		s: peopleScale(h, h) * .38,
		flip: true,
		hair: "long",
		shirt: PAL.shirt,
		skirt: true,
		mood: "soft",
		pose: "stand",
		ribbon: PAL.sunset,
		phase: live,
		reveal: pr
	});
	const lead = revealAt(local, .4, .4);
	const px = x + Math.floor(clamp(local / 2) * 4) % 4 / 3 * ww;
	const py = y + (clamp(local / 8) > .5 ? wh : 8);
	pencilTool(ctx, local < 9 ? px : x + ww - 10, local < 9 ? py : y + wh - 8, -.7, lead);
	if (!poster) {
		const tr = revealAt(local, 14, 5);
		const size = Math.min(w * .078, 68);
		ctx.save();
		ctx.beginPath();
		ctx.rect(w / 2 - size * 5, h * .78 - size, size * 10 * tr, size * 2.2);
		ctx.clip();
		brush(ctx, "把回忆拼好给你", w / 2, h * .78, size, PAL.ink, 1);
		ctx.restore();
		brush(ctx, "王贰浪", w / 2, h * .78 + size * .85, size * .38, PAL.inkSoft, clamp(tr * 1.4 - .3));
	}
}
function keepsake(f) {
	const { ctx, w, h, live, local, tone } = f;
	const gy = groundY(h);
	const night = tone === "night";
	const dawn = tone === "dawn";
	const dusk = tone === "dusk";
	if (night) {
		overscan(ctx, w, h, (g) => {
			g.addColorStop(0, PAL.night);
			g.addColorStop(gy / h, PAL.nightMid);
			g.addColorStop(Math.min(.99, gy / h + .01), "#d9cbb6");
			g.addColorStop(1, PAL.paperDeep);
		});
		stars(ctx, w, gy * .72, live, 28);
	} else if (dusk) overscan(ctx, w, h, (g) => {
		g.addColorStop(0, "#f0b48a");
		g.addColorStop(gy / h, "#f6d7b4");
		g.addColorStop(1, PAL.paper);
	});
	else if (dawn) overscan(ctx, w, h, (g) => {
		g.addColorStop(0, "#f7d7b0");
		g.addColorStop(.45, "#fbe7cf");
		g.addColorStop(1, PAL.paper);
	});
	else {
		overscan(ctx, w, h, (g) => {
			g.addColorStop(0, "#f6f0e6");
			g.addColorStop(1, PAL.paper);
		});
		margin(ctx, h);
	}
	const ww = Math.min(w * .28, 240);
	const wh = ww * .8;
	const wx = w * .68;
	const wy = h * .1;
	ctx.save();
	ctx.fillStyle = night ? "#24344e" : dawn ? "#f8e2c0" : "#dce8ef";
	ctx.globalAlpha = revealAt(local, .2, .8);
	ctx.fillRect(wx, wy, ww, wh);
	ctx.restore();
	windowFrame(ctx, wx, wy, ww, wh, revealAt(local, .15, 1.2));
	if (night) moon(ctx, wx + ww * .7, wy + wh * .38, wh * .22, revealAt(local, .4, .8));
	const fly = tone === "dawn" ? clamp((local - 6) / 6) : clamp((local - 8) / 7);
	const bx = tone === "dawn" ? lerp(w + 30, wx + ww * .3, fly) : lerp(wx + 30, w + 40, fly);
	const by = wy + wh * .55 - Math.sin(fly * Math.PI) * 40;
	if (local < 6 || fly < .98) bird(ctx, local < (tone === "dawn" ? 6 : 8) ? wx + ww * .3 : bx, local < 8 && tone !== "dawn" ? wy + wh * .62 : by, .85, live * 8, revealAt(local, 1, .8), fly * .2);
	const desk = gy - 8;
	fillPoly(ctx, [
		[w * .08, desk],
		[w * .92, desk],
		[w + 10, h + 10],
		[-10, h + 10]
	], night ? "#e6d7c2" : PAL.desk, 1);
	stroke(ctx, [[w * .06, desk], [w * .94, desk + 1]], {
		w: 2,
		seed: 11,
		reveal: revealAt(local, .2, .6)
	});
	blot(ctx, w * .22, desk - 10, 70, 40, PAL.sun, (.18 + f.energy * .25) * revealAt(local, .4, .5));
	clock(ctx, w * .18, desk - 78, 26, live * 1.6, revealAt(local, .5, .8));
	const boxX = w * .42;
	frameRect(ctx, boxX, desk - 46, 78, 40, revealAt(local, .3, .7), PAL.ink, 1.8);
	ctx.save();
	ctx.globalAlpha = revealAt(local, .3, .7);
	ctx.fillStyle = PAL.wood;
	ctx.fillRect(boxX, desk - 46, 78, 40);
	ctx.restore();
	for (let i = 0; i < 5; i++) {
		const rv = revealAt(local, .6 + i * .55, .7);
		const bob = Math.sin(live * .8 + i) * 2;
		polaroid(ctx, boxX + 20 + (i - 2) * 28, desk - 78 - i * 6 + bob, (i - 2) * .08, .72, rv, () => photoInner(ctx, i));
	}
	const palm = revealAt(local, 13.5, 1.4);
	if (palm > .02) {
		openPalm(ctx, w * .62, h * .86, Math.min(1.3, w / 700), palm);
		heart(ctx, w * .62, h * .78, .7, PAL.rose, revealAt(local, 14.6, .8));
	}
}
function starsScene(f) {
	const { ctx, w, h, live, local } = f;
	const gy = groundY(h);
	const weary = smooth(clamp((local - 5.2) / 3));
	overscan(ctx, w, h, (g) => {
		g.addColorStop(0, lerpColor(weary, "#24344e", "#1a2030"));
		g.addColorStop(gy / h, lerpColor(weary, "#6d83a4", "#2a3344"));
		g.addColorStop(1, "#e7dcc8");
	});
	stars(ctx, w, gy * .8, live, Math.floor(lerp(40, 14, weary)));
	floor(ctx, w, h, gy, "#e5d8c4");
	const ps = peopleScale(h, gy);
	const jx = w * .58;
	const jy = gy - 70;
	oval(ctx, jx, jy, 34, 46, {
		w: 1.8,
		reveal: revealAt(local, .3, .8),
		seed: 12
	});
	const count = Math.floor(lerp(14, 4, weary));
	for (let i = 0; i < count; i++) {
		const rise = weary * (20 + i * 6);
		const tw = .4 + Math.sin(live * 3 + i) * .4;
		starShape(ctx, jx + Math.sin(i) * 16, jy - 10 - i % 5 * 8 - rise, 4, PAL.gold, tw * revealAt(local, .4 + i * .08, .4));
	}
	person(ctx, {
		x: w * .34,
		y: gy,
		s: ps,
		hair: "short",
		shirt: PAL.jacket,
		mood: weary > .55 ? "sad" : "soft",
		pose: weary > .45 ? "sit" : "stand",
		phase: live,
		reveal: revealAt(local, .2, .9)
	});
	person(ctx, {
		x: w * .5,
		y: gy,
		s: ps,
		flip: true,
		hair: "long",
		shirt: PAL.shirt,
		skirt: true,
		ribbon: PAL.sunset,
		mood: "smile",
		pose: "stand",
		phase: live,
		reveal: revealAt(local, .4, .8) * (1 - weary)
	});
	blot(ctx, w * .22, gy - 120, 40, 26, PAL.sun, (.2 + f.energy * .2) * (1 - weary * .7));
}
function street(f) {
	const { ctx, w, h, live, local, span } = f;
	const gy = groundY(h);
	const u = clamp(local / span);
	const top = lerpColor(u, "#d7e8f2", "#f0b48c");
	const mid = lerpColor(u, "#f7efe4", "#f6c7a4");
	overscan(ctx, w, h, (g) => {
		g.addColorStop(0, top);
		g.addColorStop(gy / h, mid);
		g.addColorStop(1, "#e7d3b4");
	});
	sun(ctx, lerp(w * .78, w * .7, u), lerp(h * .16, gy - 20, u), 28, revealAt(local, .2, .6));
	hills(ctx, w, h, gy, [{
		y: gy - 30,
		amp: 18,
		color: "#e7cbb0",
		seed: 1
	}, {
		y: gy - 8,
		amp: 10,
		color: "#ecdcc6",
		seed: 2
	}]);
	floor(ctx, w, h, gy, "#e6d5bc");
	fallingLeaves(ctx, w, gy, live, 18);
	crowd(ctx, w, gy, live, revealAt(local, .3, .6));
	const ps = peopleScale(h, gy) * .92;
	const walk = smooth(clamp(local / (span * .8)));
	const x = lerp(w * .28, w * .46, walk);
	const dust = 1 - smooth(clamp(local / 3.2));
	for (let i = 0; i < 8; i++) {
		const a = live * 1.4 + i;
		blot(ctx, x + Math.cos(a) * 26 * dust, gy - 80 + Math.sin(a * 1.3) * 30, 3, 3, PAL.inkSoft, dust * .35);
	}
	person(ctx, {
		x,
		y: gy,
		s: ps,
		hair: "short",
		shirt: PAL.jacket,
		mood: "smile",
		pose: "walk",
		phase: live * 3,
		reveal: revealAt(local, .2, 1) * (1 - dust * .35)
	});
	person(ctx, {
		x: x + 62 * ps,
		y: gy,
		s: ps,
		flip: true,
		hair: "long",
		shirt: PAL.shirt,
		skirt: true,
		ribbon: PAL.sunset,
		mood: "smile",
		pose: "walk",
		phase: live * 3 + .4,
		reveal: revealAt(local, .45, 1)
	});
	stroke(ctx, [[x + 18 * ps, gy - 78], [x + 46 * ps, gy - 78]], {
		w: 1.5,
		color: PAL.inkSoft,
		reveal: revealAt(local, 1, .6),
		seed: 15
	});
	pot(ctx, w * .82, gy - 6, smooth(clamp((local - 4.6) / 3.5)), revealAt(local, 4.2, .8));
}
function panel(ctx, x, y, pw, ph, reveal, draw) {
	ctx.save();
	ctx.beginPath();
	ctx.rect(x, y, Math.max(.01, pw), ph);
	ctx.clip();
	ctx.fillStyle = "#fbf6ec";
	ctx.globalAlpha = clamp(reveal);
	ctx.fillRect(x, y, pw, ph);
	ctx.globalAlpha = 1;
	if (reveal > .05) draw();
	ctx.restore();
	frameRect(ctx, x, y, pw, ph, reveal, PAL.ink, 1.6);
}
function knowyou(f) {
	const { ctx, w, h, live, local } = f;
	overscan(ctx, w, h, (g) => {
		g.addColorStop(0, "#f7f1e6");
		g.addColorStop(1, PAL.paper);
	});
	margin(ctx, h);
	const gap = Math.max(8, w * .02);
	const left = w * .08;
	const top = h * .06;
	const pw = (w * .84 - gap) / 2;
	const ph = (h * .58 - gap) / 2;
	const ps = Math.min(pw, ph) / 260;
	panel(ctx, left, top, pw, ph, revealAt(local, .1, .7), () => {
		for (let i = 0; i < 3; i++) {
			frameRect(ctx, left + 16 + i * 28, top + ph * .28, 22, 28, 1, PAL.inkSoft, 1);
			heart(ctx, left + 27 + i * 28, top + ph * .4, .28, i === 1 ? PAL.blue : PAL.rose, 1);
		}
		brush(ctx, "集邮", left + pw * .5, top + ph * .78, Math.max(16, pw * .12), PAL.inkSoft, .8);
	});
	panel(ctx, left + pw + gap, top, pw, ph, revealAt(local, 1.3, .7), () => {
		person(ctx, {
			x: left + pw + gap + pw * .55,
			y: top + ph * .86,
			s: ps * 1.15,
			hair: "long",
			shirt: PAL.shirt,
			skirt: true,
			ribbon: PAL.sunset,
			mood: local > 6 ? "shy" : "smile",
			pose: "wave",
			phase: live,
			reveal: 1
		});
	});
	panel(ctx, left, top + ph + gap, pw, ph, revealAt(local, 3.1, .8), () => {
		ctx.fillStyle = local > 4.2 ? "#243044" : "#e7f0e4";
		ctx.fillRect(left, top + ph + gap, pw, ph);
		if (local > 4.2) moon(ctx, left + pw * .75, top + ph + gap + 28, 16, 1);
		bug(ctx, left + pw * .3, top + ph + gap + ph * .62, 1.4, 1);
		if (local > 4.4) ghost(ctx, left + pw * .62, top + ph + gap + ph * .55, 1.1, revealAt(local, 4.4, .6));
	});
	panel(ctx, left + pw + gap, top + ph + gap, pw, ph, revealAt(local, 6.2, .8), () => {
		const spin = live * 2;
		for (let i = 0; i < 3; i++) {
			const a = spin + i * 2;
			stroke(ctx, [[left + pw + gap + pw / 2, top + ph + gap + ph * .45], [left + pw + gap + pw / 2 + Math.cos(a) * 30, top + ph + gap + ph * .45 + Math.sin(a) * 12]], {
				w: 1,
				color: PAL.faint,
				a: .7,
				passes: 1,
				seed: i
			});
		}
		person(ctx, {
			x: left + pw + gap + pw * .5,
			y: top + ph + gap + ph * .88,
			s: ps * .85,
			hair: "long",
			shirt: PAL.gold,
			skirt: true,
			mood: "smile",
			pose: "wave",
			phase: live * 2,
			reveal: 1
		});
	});
	const note = revealAt(local, 11.6, 1);
	if (note > .02) letter(ctx, w / 2, h * .78, Math.min(w * .46, 280), 64, note);
}
function dawn(f) {
	const { ctx, w, h, live, local, span } = f;
	const u = clamp(local / span);
	const gy = groundY(h);
	overscan(ctx, w, h, (g) => {
		g.addColorStop(0, lerpColor(u, "#141a28", "#f6c9a0"));
		g.addColorStop(gy / h, lerpColor(u, "#31405c", "#fbe6cf"));
		g.addColorStop(1, lerpColor(u, "#cbbca6", "#f3e2cc"));
	});
	if (u < .7) stars(ctx, w, gy, live, Math.floor(30 * (1 - u)));
	sun(ctx, w * .5, lerp(gy + 40, h * .28, smooth(clamp((u - .35) / .5))), 36, smooth(clamp((u - .3) / .4)));
	floor(ctx, w, h, gy, "#f0e2cc");
	const ps = peopleScale(h, gy) * .85;
	person(ctx, {
		x: w * .5,
		y: gy,
		s: ps,
		hair: "short",
		shirt: PAL.jacket,
		mood: u > .55 ? "soft" : "sleep",
		pose: u > .4 ? "stand" : "sit",
		phase: live,
		reveal: 1
	});
	const blooms = 7;
	for (let i = 0; i < blooms; i++) {
		const open = smooth(clamp((local - 3.2 - i * .18) / 1.1));
		flower(ctx, w * .18 + i * (w * .64 / blooms), gy, .9, open, i % 2 ? PAL.blush : PAL.white);
	}
}
function rainScene(f) {
	const { ctx, w, h, live, local } = f;
	const gy = groundY(h);
	const color = smooth(clamp((local - 2.6) / 3.2));
	overscan(ctx, w, h, (g) => {
		g.addColorStop(0, lerpColor(color, "#e7e4de", "#f3c3a6"));
		g.addColorStop(gy / h, lerpColor(color, "#f4efe8", "#f8dcc4"));
		g.addColorStop(1, "#e7dcc8");
	});
	if (color < .85) rain(ctx, w, gy, live, gy, (1 - color) * .7);
	sun(ctx, w * .8, h * .2, 26, color);
	hills(ctx, w, h, gy, [{
		y: gy - 16,
		amp: 12,
		color: lerpColor(color, "#e5ddd2", "#f0cbb4"),
		seed: 2
	}]);
	floor(ctx, w, h, gy, "#e4d6c2");
	const ps = peopleScale(h, gy) * .9;
	const x = w * .42;
	umbrella(ctx, x + 24 * ps, gy - 168 * ps, ps, color > .4 ? PAL.blue : "#d9d3c8", revealAt(local, .2, .8));
	person(ctx, {
		x,
		y: gy,
		s: ps,
		hair: "short",
		shirt: PAL.jacket,
		mood: color > .5 ? "smile" : "shy",
		pose: "stand",
		phase: live,
		reveal: revealAt(local, .3, .8)
	});
	person(ctx, {
		x: x + 58 * ps,
		y: gy,
		s: ps,
		flip: true,
		hair: "long",
		shirt: PAL.shirt,
		skirt: true,
		ribbon: PAL.sunset,
		mood: "smile",
		pose: "stand",
		phase: live,
		reveal: revealAt(local, .5, .8)
	});
	ctx.save();
	ctx.translate(w * .3, gy + 6);
	ctx.scale(1, .28);
	oval(ctx, 0, 0, 70, 70, {
		w: 1.3,
		color: PAL.blueDeep,
		a: .45,
		seed: 17
	});
	ctx.restore();
	blot(ctx, w * .3, gy + 4, 54, 10, color > .3 ? PAL.sunset : PAL.blue, .25);
	const gift = revealAt(local, 7.4, 1);
	if (gift > .02) {
		polaroid(ctx, w * .78, gy - 70, -.06, 1.15, gift, () => {
			ctx.fillStyle = "#d5e6ef";
			ctx.fillRect(-40, -52, 80, 68);
			person(ctx, {
				x: 0,
				y: 36,
				s: .42,
				hair: "long",
				shirt: PAL.blue,
				skirt: true,
				ribbon: PAL.blueDeep,
				mood: "smile",
				pose: "stand",
				reveal: 1
			});
		});
		bow(ctx, w * .78, gy - 128, .7, gift);
	}
}
function room(f, cold) {
	const { ctx, w, h, live, local } = f;
	const gy = groundY(h);
	const night = cold || local > 5;
	overscan(ctx, w, h, (g) => {
		if (cold) {
			g.addColorStop(0, "#d5dde6");
			g.addColorStop(1, "#e4e0da");
		} else if (night) {
			g.addColorStop(0, "#2a3548");
			g.addColorStop(.55, "#3d4d66");
			g.addColorStop(1, "#e6d8c4");
		} else {
			g.addColorStop(0, "#f6efe4");
			g.addColorStop(1, "#f3e6d2");
		}
	});
	const ww = Math.min(w * .22, 180);
	windowFrame(ctx, w * .12, h * .12, ww, ww * .75, 1);
	ctx.save();
	ctx.fillStyle = night && !cold ? "#1c2838" : "#d7e6ee";
	ctx.globalAlpha = .85;
	ctx.fillRect(w * .12, h * .12, ww, ww * .75);
	ctx.restore();
	floor(ctx, w, h, gy, cold ? "#ddd6cc" : "#eadcc6");
	const couchY = gy;
	const couchX = w * .5;
	const couchW = Math.min(w * .55, 460);
	ctx.save();
	ctx.fillStyle = cold ? "#8aa0b0" : "#c4785a";
	ctx.globalAlpha = .9;
	ctx.fillRect(couchX - couchW / 2, couchY - 48, couchW, 36);
	ctx.restore();
	frameRect(ctx, couchX - couchW / 2, couchY - 52, couchW, 40, 1, PAL.ink, 1.6);
	return {
		gy,
		couchX,
		couchW,
		ps: peopleScale(h, gy) * .78
	};
}
function days(f) {
	const { ctx, w, live, local } = f;
	const { gy, couchX, ps } = room(f, false);
	const night = smooth(clamp((local - 4) / 3));
	person(ctx, {
		x: couchX - 50,
		y: gy - 8,
		s: ps,
		hair: "short",
		shirt: PAL.jacket,
		mood: "smile",
		pose: "sit",
		phase: live,
		reveal: 1
	});
	person(ctx, {
		x: couchX + 46,
		y: gy - 8,
		s: ps,
		flip: true,
		hair: "long",
		shirt: PAL.shirt,
		skirt: true,
		ribbon: PAL.sunset,
		mood: "smile",
		pose: "sit",
		phase: live + .4,
		reveal: 1
	});
	if (night < .5) blocks(ctx, w * .5 - 20, gy - 6, 1 - night);
	tv(ctx, w * .78, gy - 70, 1, live, night);
}
function rift(f) {
	const { ctx, w, h, live, local } = f;
	const { gy, couchX, ps } = room(f, true);
	const gap = lerp(40, 110, smooth(clamp(local / 6)));
	person(ctx, {
		x: couchX - gap,
		y: gy - 8,
		s: ps,
		hair: "short",
		shirt: "#9aa7b2",
		mood: "sad",
		pose: "apart",
		phase: live,
		reveal: 1
	});
	person(ctx, {
		x: couchX + gap,
		y: gy - 8,
		s: ps,
		flip: true,
		hair: "long",
		shirt: "#b7c6d0",
		skirt: true,
		mood: "sad",
		pose: "apart",
		phase: live,
		reveal: 1
	});
	phone(ctx, couchX - gap - 24, gy - 20, 1.1, true, revealAt(local, .4, .6));
	phone(ctx, couchX + gap + 10, gy - 18, 1.1, true, revealAt(local, .8, .6));
	const tearX = w * .5 + Math.sin(local) * 4;
	ctx.save();
	ctx.strokeStyle = "rgba(90,70,60,0.55)";
	ctx.lineWidth = 2;
	ctx.setLineDash([5, 6]);
	ctx.beginPath();
	ctx.moveTo(tearX, h * .08);
	for (let y = h * .08; y < h; y += 16) ctx.lineTo(tearX + Math.sin(y * .08) * 8, y);
	ctx.stroke();
	ctx.restore();
	const scar = revealAt(local, 5, 1.2);
	heart(ctx, w * .5, gy - 90, .85, PAL.rose, scar * .85);
	for (let i = -2; i <= 2; i++) stroke(ctx, [[w * .5 - 10, gy - 90 + i * 8], [w * .5 + 10, gy - 90 + i * 8]], {
		w: 1.2,
		color: PAL.gold,
		reveal: scar,
		seed: i + 4
	});
}
function spark(f) {
	const { ctx, w, h, live, local } = f;
	const gy = groundY(h);
	overscan(ctx, w, h, (g) => {
		g.addColorStop(0, "#141a2a");
		g.addColorStop(gy / h, "#2c3c58");
		g.addColorStop(1, "#d9cbb8");
	});
	stars(ctx, w, gy * .75, live, 26);
	floor(ctx, w, h, gy, "#d7c9b4");
	stroke(ctx, [[w * .08, gy - 36], [w * .92, gy - 34]], {
		w: 2,
		color: PAL.inkSoft,
		seed: 4
	});
	const ps = peopleScale(h, gy) * .82;
	person(ctx, {
		x: w * .4,
		y: gy,
		s: ps,
		hair: "short",
		shirt: PAL.jacket,
		mood: "soft",
		pose: "reach",
		phase: live,
		reveal: 1
	});
	person(ctx, {
		x: w * .58,
		y: gy,
		s: ps,
		flip: true,
		hair: "long",
		shirt: PAL.shirt,
		skirt: true,
		ribbon: PAL.sunset,
		mood: "smile",
		pose: "stand",
		phase: live,
		reveal: 1
	});
	const open = smooth(clamp((local - 1.2) / 3));
	paperFlower(ctx, w * .72, gy - 120, 1.1, open);
	firework(ctx, w * .3, h * .24, live, f.t - local + 6.4, PAL.sun);
	firework(ctx, w * .62, h * .18, live, f.t - local + 7.6, PAL.blush);
	firework(ctx, w * .78, h * .28, live, f.t - local + 8.7, PAL.blue);
	const joy = revealAt(local, 7.6, 1.2);
	for (let i = 0; i < 4; i++) {
		const u = smooth(clamp(joy * 1.2 - i * .08));
		scrap(ctx, lerp(w * (.15 + i * .2), w * .42 + i * 36, u), lerp(h * .3, gy - 150, u), 42, (1 - u) * (i - 1.5) * .4, joy, PAL.gold, (c) => {
			starShape(c, 0, 2, 8, PAL.sun, 1);
		});
	}
}
function grow(f) {
	const { ctx, w, h, live, local, span } = f;
	const gy = groundY(h);
	const u = clamp(local / span);
	overscan(ctx, w, h, (g) => {
		g.addColorStop(0, "#f6d0a8");
		g.addColorStop(gy / h, "#f8e6cf");
		g.addColorStop(1, "#e7d5bc");
	});
	sun(ctx, w * .18, h * .16, 26, 1);
	hills(ctx, w, h, gy, [{
		y: gy - 70,
		amp: 26,
		color: "#c5b7a4",
		seed: 1
	}, {
		y: gy - 36,
		amp: 16,
		color: "#d9c3a4",
		seed: 2
	}]);
	const sea = smooth(clamp((u - .35) / .3));
	if (sea > .02) {
		ctx.save();
		ctx.globalAlpha = sea;
		ctx.fillStyle = PAL.sea;
		ctx.fillRect(w * .62, gy - 28, w * .4, 30);
		ctx.restore();
		for (let i = 0; i < 4; i++) stroke(ctx, [
			[w * .64, gy - 16 + i * 6],
			[w * .78, gy - 20 + i * 6],
			[w * .95, gy - 14 + i * 6]
		], {
			w: 1.3,
			color: "#d5e8ee",
			a: .7 * sea,
			seed: i
		});
	}
	floor(ctx, w, h, gy, "#e8d7be");
	fillPoly(ctx, [
		[w * .5, gy - 80],
		[w * .2, gy],
		[w * .85, gy]
	], "#e7d3b2", .65);
	const growU = smooth(clamp((u - .05) / .7));
	const ps = peopleScale(h, gy) * lerp(.48, 1, growU);
	const x = lerp(w * .34, w * .48, u);
	const pray = u > .72;
	person(ctx, {
		x: x - 28 * ps,
		y: gy,
		s: ps * .72,
		hair: "short",
		shirt: PAL.gold,
		mood: "smile",
		pose: "walk",
		phase: live * 3,
		reveal: 1 - smooth(clamp((u - .2) / .35))
	});
	person(ctx, {
		x,
		y: gy,
		s: ps,
		hair: "short",
		shirt: PAL.jacket,
		mood: pray ? "soft" : "smile",
		pose: pray ? "pray" : "walk",
		phase: live * 2.4,
		reveal: revealAt(local, .2, .6)
	});
	person(ctx, {
		x: x + 54 * ps,
		y: gy,
		s: ps,
		flip: true,
		hair: "long",
		shirt: PAL.shirt,
		skirt: true,
		ribbon: PAL.sunset,
		mood: "smile",
		pose: pray ? "pray" : "walk",
		phase: live * 2.4 + .5,
		reveal: revealAt(local, .4, .6)
	});
	if (pray) starShape(ctx, w * .5, gy - 210 * ps, 10, PAL.gold, revealAt(local, span * .72, 1));
	bird(ctx, live * 40 % (w + 40) - 20, h * .22, .7, live * 10, .8, -.1);
}
function moonScene(f) {
	const { ctx, w, h, live, local } = f;
	const gy = groundY(h);
	overscan(ctx, w, h, (g) => {
		g.addColorStop(0, "#141a28");
		g.addColorStop(gy / h, "#2d3e5c");
		g.addColorStop(1, "#d5c8b4");
	});
	stars(ctx, w, gy * .55, live, 20);
	const u = clamp(local / f.span);
	const mr = lerp(h * .08, Math.min(h, w) * .26, smooth(u));
	const my = lerp(h * .22, h * .3, u);
	moon(ctx, w * .62, my, mr, 1);
	for (const a of [
		0,
		5.88,
		11.88,
		18.27
	]) {
		const age = local - a;
		if (age > 0 && age < 2.4) oval(ctx, w * .62, my, mr + age * 28, mr + age * 28, {
			w: 1.4,
			color: PAL.gold,
			a: 1 - age / 2.4,
			seed: a,
			passes: 1
		});
	}
	hills(ctx, w, h, gy, [{
		y: gy - 10,
		amp: 14,
		color: "#cbbba6",
		seed: 3
	}]);
	floor(ctx, w, h, gy, "#d8cbb8");
	const ps = peopleScale(h, gy) * .8;
	const smile = local > 2.2 && local < 8;
	person(ctx, {
		x: w * .32,
		y: gy,
		s: ps,
		hair: "short",
		shirt: PAL.jacket,
		mood: local > 16 ? "soft" : smile ? "smile" : "sad",
		pose: "sit",
		phase: live * .4,
		reveal: 1
	});
	if (local > 7 && local < 16) {
		const loose = smooth(clamp((local - 8) / 4));
		kite(ctx, lerp(w * .48, w * .7, loose), lerp(gy - 150, h * .18, loose), .9, revealAt(local, 7, .6));
		stroke(ctx, [[w * .36, gy - 70], [lerp(w * .48, w * .7, loose), lerp(gy - 120, h * .24, loose)]], {
			w: 1.1,
			color: PAL.faint,
			a: 1 - loose * .7,
			seed: 19
		});
	}
	if (local > 22) {
		const wr = revealAt(local, 23.6, 1.4);
		ctx.save();
		ctx.beginPath();
		ctx.rect(w * .62 - mr, my - 10, mr * 2 * wr, 48);
		ctx.clip();
		brush(ctx, "要爱自己啊", w * .62, my, Math.max(18, mr * .28), PAL.inkSoft, .85);
		ctx.restore();
	}
}
var SCRAPS = [
	{
		tint: "#d5e4ee",
		mark: (c) => rain(c, 80, 70, 1, 60, .5)
	},
	{
		tint: "#f6e7c4",
		mark: (c) => bird(c, 0, 4, 1.1, 1, 1)
	},
	{
		tint: "#e5f0e4",
		mark: (c) => flower(c, 0, 6, .8, 1, PAL.blush)
	},
	{
		tint: "#f6d0b0",
		mark: (c) => sun(c, 0, 0, 12, 1)
	},
	{
		tint: "#d5e6ef",
		mark: (c) => heart(c, 0, 2, .7, PAL.blue, 1)
	},
	{
		tint: "#cfe0e8",
		mark: (c) => {
			c.fillStyle = PAL.sea;
			c.fillRect(-20, 4, 40, 16);
		}
	},
	{
		tint: "#e7e0d4",
		mark: (c) => moon(c, 0, 0, 14, 1)
	},
	{
		tint: "#243044",
		mark: (c) => starShape(c, 0, 0, 10, PAL.gold, 1)
	},
	{
		tint: "#f8e4e0",
		mark: (c) => heart(c, 0, 2, .85, PAL.rose, 1)
	}
];
function pieces(f, force) {
	const { ctx, w, h, live, local, span } = f;
	const gy = groundY(h);
	overscan(ctx, w, h, (g) => {
		g.addColorStop(0, "#f3c7a4");
		g.addColorStop(.45, "#f8e6d2");
		g.addColorStop(1, PAL.paper);
	});
	sun(ctx, w * .14, h * .16, 22, .9);
	hills(ctx, w, h, gy, [{
		y: gy - 8,
		amp: 12,
		color: "#f0dcc4",
		seed: 2
	}]);
	floor(ctx, w, h, gy, "#eddcc4");
	const u = force ?? smooth(clamp((local - 4) / (span * .86)));
	const ps = peopleScale(h, gy) * .72;
	person(ctx, {
		x: w * .16,
		y: gy,
		s: ps,
		hair: "short",
		shirt: PAL.jacket,
		mood: u < .35 ? "sad" : "soft",
		pose: u > .72 ? "reach" : "stand",
		phase: live * .5,
		reveal: 1
	});
	const size = Math.min(w, h) * .13;
	const gap = size * .12;
	const gridW = 3 * size + 2 * gap;
	const x0 = w * .58 - gridW / 2 + size / 2;
	const y0 = h * .34 - gridW / 2 + size / 2;
	const palm = revealAt(u * span, span * .62, span * .2);
	if (force === 1 || u > .62) openPalm(ctx, w * .58, h * .86, Math.min(1.6, w / 520), force === 1 ? 1 : palm);
	SCRAPS.forEach((sc, i) => {
		const col = i % 3;
		const row = Math.floor(i / 3);
		const tx = x0 + col * (size + gap);
		const ty = y0 + row * (size + gap) + (1 - (force ?? u)) * 0;
		const ang = i * 2.399;
		const sx = w * .5 + Math.cos(ang) * w * .36;
		const sy = h * .4 + Math.sin(ang * 1.2) * h * .26;
		const p = force ?? u;
		const x = lerp(sx, tx, p) + Math.sin(live * .7 + i) * (1 - p) * 8;
		const y = lerp(sy, ty, p) + Math.cos(live * .6 + i) * (1 - p) * 6;
		const rot = lerp((i - 4) * .35, 0, p);
		scrap(ctx, x, y, size, rot, revealAt(local, i * .12, .5), sc.tint, () => sc.mark(ctx));
	});
	if ((force ?? u) > .92) bow(ctx, w * .58, y0 - size * .85, 1, force === 1 ? 1 : revealAt(local, span * .9, .8));
	const pulse = Math.exp(-((local - (span - 3)) ** 2) / 2.2);
	if (pulse > .05 && force == null) blot(ctx, w * .58, h * .36, 180, 140, PAL.sun, pulse * .35);
}
function coda(f) {
	pieces({
		...f,
		local: f.span
	}, 1);
	const { ctx, w, h, live } = f;
	for (let i = 0; i < 14; i++) blot(ctx, (i * 97 + Math.sin(live * .4 + i) * 20) % w, h * .15 + (i * 53 + live * 12) % (h * .5), 2.2, 2.2, PAL.gold, .35 + Math.sin(live * 2 + i) * .25);
	brush(ctx, "给你", w * .58, h * .7, Math.min(42, w * .05), PAL.inkSoft, .75);
}
function lerpColor(t, a, b) {
	const pa = hex(a);
	const pb = hex(b);
	return `rgb(${Math.round(lerp(pa[0], pb[0], t))},${Math.round(lerp(pa[1], pb[1], t))},${Math.round(lerp(pa[2], pb[2], t))})`;
}
function hex(c) {
	const h = c.replace("#", "");
	return [
		parseInt(h.slice(0, 2), 16),
		parseInt(h.slice(2, 4), 16),
		parseInt(h.slice(4, 6), 16)
	];
}
function drawCue(ctx, cue, index, w, h, t, live, energy, poster) {
	const next = CUES[index + 1]?.t0 ?? t + 40;
	const f = {
		ctx,
		w,
		h,
		t,
		live,
		local: t - cue.t0,
		span: next - cue.t0,
		energy,
		poster,
		tone: cue.tone ?? "day"
	};
	switch (cue.id) {
		case "intro":
			intro(f);
			break;
		case "keepsake":
			keepsake(f);
			break;
		case "stars":
			starsScene(f);
			break;
		case "street":
			street(f);
			break;
		case "knowyou":
			knowyou(f);
			break;
		case "dawn":
			dawn(f);
			break;
		case "rain":
			rainScene(f);
			break;
		case "days":
			days(f);
			break;
		case "rift":
			rift(f);
			break;
		case "spark":
			spark(f);
			break;
		case "grow":
			grow(f);
			break;
		case "moon":
			moonScene(f);
			break;
		case "pieces":
			pieces(f);
			break;
		case "coda": coda(f);
	}
}
function findCue(t) {
	let index = 0;
	for (let i = 0; i < CUES.length; i++) if (CUES[i].t0 <= t) index = i;
	return index;
}
function clipWipe(ctx, w, h, u, live) {
	const edge = -30 + u * (w + 70);
	ctx.beginPath();
	ctx.moveTo(-60, -60);
	ctx.lineTo(edge, -60);
	for (let y = -40; y <= h + 60; y += 14) ctx.lineTo(edge + Math.sin(y * .045 + live) * 9, y);
	ctx.lineTo(-60, h + 60);
	ctx.closePath();
	ctx.clip();
}
function paint(ctx, w, h, t, live, energy, poster = false) {
	if (w < 8 || h < 8) return;
	setFrameLive(live);
	const index = findCue(t);
	const cue = CUES[index];
	const prev = index > 0 ? CUES[index - 1] : null;
	const into = t - cue.t0;
	const wipeDur = 1.05;
	ctx.save();
	ctx.beginPath();
	ctx.rect(0, 0, w, h);
	ctx.clip();
	const dx = Math.sin(live * .2) * 5;
	const dy = Math.cos(live * .16) * 3;
	ctx.translate(dx, dy);
	if (prev && into >= 0 && into < wipeDur) {
		drawCue(ctx, prev, index - 1, w, h, t, live, energy, false);
		ctx.save();
		clipWipe(ctx, w, h, into / wipeDur, live);
		drawCue(ctx, cue, index, w, h, t, live, energy, poster);
		ctx.restore();
		const edge = -30 + into / wipeDur * (w + 70);
		stroke(ctx, Array.from({ length: 18 }, (_, i) => {
			const y = i / 17 * h;
			return [edge + Math.sin(y * .045 + live) * 9, y];
		}), {
			w: 1.4,
			color: PAL.inkSoft,
			a: .45,
			passes: 1,
			seed: 7
		});
	} else drawCue(ctx, cue, index, w, h, t, live, energy, poster);
	ctx.restore();
	const pattern = paperGrain(ctx);
	if (pattern) {
		ctx.save();
		ctx.globalAlpha = .2;
		ctx.fillStyle = pattern;
		ctx.fillRect(0, 0, w, h);
		ctx.restore();
	}
	vignette(ctx, w, h);
}
var LYRICS = [
	{
		t: 27.48,
		text: "我们之间的回忆"
	},
	{
		t: 30.73,
		text: "全部都小心地收集"
	},
	{
		t: 33.73,
		text: "我总是偷偷地哭泣"
	},
	{
		t: 36.73,
		text: "像倦鸟失了归期"
	},
	{
		t: 39.11,
		text: "但愿我相信的爱情"
	},
	{
		t: 42.36,
		text: "结局紧握在我手心"
	},
	{
		t: 45.11,
		text: "时光匆匆却没有遗失过去"
	},
	{
		t: 54.87,
		text: "希望我们 有光明的未来"
	},
	{
		t: 57.86,
		text: "还有能够装下星空的期待"
	},
	{
		t: 60.86,
		text: "可现实为何让我感到如此懈怠"
	},
	{
		t: 64.11,
		text: "总怀念相遇时"
	},
	{
		t: 65.25,
		text: "我们无视落叶和人海"
	},
	{
		t: 67,
		text: "是你让我勇敢不再像颗尘埃"
	},
	{
		t: 70.25,
		text: "是你常帮我照料装着梦的盆栽"
	},
	{
		t: 73.25,
		text: "每一天我们都是如此愉快"
	},
	{
		t: 75.75,
		text: "一直到天色渐晚"
	},
	{
		t: 77.5,
		text: "看着落日无奈离开"
	},
	{
		t: 79.14,
		text: "我知道你爱集邮"
	},
	{
		t: 80.53,
		text: "爱笑甚至爱发呆"
	},
	{
		t: 82.28,
		text: "我知道你怕草虫"
	},
	{
		t: 83.54,
		text: "还有夜晚的妖怪"
	},
	{
		t: 85.28,
		text: "我喜欢你有一点"
	},
	{
		t: 86.78,
		text: "心不在焉的状态"
	},
	{
		t: 88.03,
		text: "看起来像个回到"
	},
	{
		t: 89.68,
		text: "七岁时候的小孩"
	},
	{
		t: 91.68,
		text: "该如何将我这份感情"
	},
	{
		t: 93.18,
		text: "向你告白"
	},
	{
		t: 94.43,
		text: "喜欢却又不敢爱"
	},
	{
		t: 95.68,
		text: "直到整个宇宙"
	},
	{
		t: 97.43,
		text: "在为我焦虑失神"
	},
	{
		t: 98.56,
		text: "慌张之中醒来"
	},
	{
		t: 100.06,
		text: "就像是黑暗过后黎明盛开"
	},
	{
		t: 102.7,
		text: "我们之间的回忆"
	},
	{
		t: 105.2,
		text: "全部都小心地收集"
	},
	{
		t: 108.2,
		text: "我总是偷偷地哭泣"
	},
	{
		t: 111.2,
		text: "像倦鸟失了归期"
	},
	{
		t: 114.2,
		text: "但愿我相信的爱情"
	},
	{
		t: 116.95,
		text: "结局紧握在我手心"
	},
	{
		t: 120.2,
		text: "时光匆匆却没有遗失过去"
	},
	{
		t: 139.2,
		text: "那天你在雨后街角"
	},
	{
		t: 140.7,
		text: "答应接受我的爱"
	},
	{
		t: 142.2,
		text: "那一刻我的世界有了色彩"
	},
	{
		t: 145.2,
		text: "这一生无法忘记"
	},
	{
		t: 146.7,
		text: "关于澄蓝色的你"
	},
	{
		t: 148.2,
		text: "像一份礼物悄然"
	},
	{
		t: 149.34,
		text: "呈现在我的境遇"
	},
	{
		t: 151.09,
		text: "我们从清晨起玩一整天游戏"
	},
	{
		t: 154.09,
		text: "到夜晚一起看我最爱的剧"
	},
	{
		t: 157.1,
		text: "能够拥有这些已足够幸运"
	},
	{
		t: 159.85,
		text: "我已经不再期待其他什么东西"
	},
	{
		t: 163.49,
		text: "我们也经常争执互相不接电话"
	},
	{
		t: 166.25,
		text: "在同一房间终于呼叫冷漠抵达"
	},
	{
		t: 168.99,
		text: "也曾想过以后生活没有人牵挂"
	},
	{
		t: 171.99,
		text: "把爱扔掉只剩一块残酷伤疤"
	},
	{
		t: 174.99,
		text: "而那些你送我的梦"
	},
	{
		t: 176.99,
		text: "教我折的花"
	},
	{
		t: 178.75,
		text: "逃亡的盛夏"
	},
	{
		t: 180.24,
		text: "在夜空隐没之际"
	},
	{
		t: 181.62,
		text: "为我点燃烟花"
	},
	{
		t: 183.12,
		text: "寂寞时让我把快乐拼起来吧"
	},
	{
		t: 186.38,
		text: "我们之间的回忆"
	},
	{
		t: 189.12,
		text: "全部都小心地收集"
	},
	{
		t: 192.13,
		text: "我总是偷偷地哭泣"
	},
	{
		t: 195.12,
		text: "像倦鸟失了归期"
	},
	{
		t: 198.13,
		text: "但愿我相信的爱情"
	},
	{
		t: 201.63,
		text: "结局紧握在我手心"
	},
	{
		t: 204.13,
		text: "时光匆匆却没有遗失过去"
	},
	{
		t: 209.87,
		text: "我们可以就像是孩子一样成长"
	},
	{
		t: 216.88,
		text: "永远无所畏惧义无反顾"
	},
	{
		t: 219.76,
		text: "向着未知的前方"
	},
	{
		t: 222.26,
		text: "原来我们每天努力长成"
	},
	{
		t: 226.01,
		text: "看似大人的模样"
	},
	{
		t: 228.51,
		text: "为了可以一起跨越山和海洋"
	},
	{
		t: 234.01,
		text: "那时的我每天都祈祷"
	},
	{
		t: 236.78,
		text: "实现这个梦想"
	},
	{
		t: 241.28,
		text: "现在的你还好吗"
	},
	{
		t: 243.66,
		text: "是否还会像从前一样的爱笑"
	},
	{
		t: 247.16,
		text: "现在的你还好吗"
	},
	{
		t: 249.66,
		text: "当你径直在我面前坦言放下"
	},
	{
		t: 253.16,
		text: "现在的你还好吗"
	},
	{
		t: 255.66,
		text: "是否像从前一样"
	},
	{
		t: 257.05,
		text: "有无限的温柔啊"
	},
	{
		t: 259.55,
		text: "现在的你还好吗"
	},
	{
		t: 262.55,
		text: "愿你能保持月亮般的心"
	},
	{
		t: 265.8,
		text: "要爱自己啊"
	},
	{
		t: 267.2,
		text: "我们之间的回忆"
	},
	{
		t: 269.95,
		text: "全部都小心地收集"
	},
	{
		t: 272.95,
		text: "我总是偷偷地哭泣"
	},
	{
		t: 275.95,
		text: "像倦鸟失了归期"
	},
	{
		t: 279.2,
		text: "但愿我相信的爱情"
	},
	{
		t: 281.95,
		text: "结局紧握在我手心"
	},
	{
		t: 285.2,
		text: "时光匆匆却没有遗失过去"
	},
	{
		t: 291.32,
		text: "独自收集两个人之间的回忆"
	},
	{
		t: 294.82,
		text: "即使每当到这时候我都会哭泣"
	},
	{
		t: 297.82,
		text: "为何一切，变得如此"
	},
	{
		t: 300.57,
		text: "无法回到过去"
	},
	{
		t: 303.57,
		text: "但我仍愿意感谢你给过我爱情"
	},
	{
		t: 306.57,
		text: "每一场风景都是我们爱的证明"
	},
	{
		t: 309.57,
		text: "就算如今，天各一方"
	},
	{
		t: 312.82,
		text: "祝你余生动听啊"
	},
	{
		t: 315.57,
		text: "独自收集两个人之间的回忆"
	},
	{
		t: 318.57,
		text: "即使每当到这时候我都会哭泣"
	},
	{
		t: 321.57,
		text: "为何一切，变得如此"
	},
	{
		t: 324.57,
		text: "无法回到过去"
	},
	{
		t: 327.82,
		text: "但我仍愿意感谢你给过我爱情"
	},
	{
		t: 330.82,
		text: "每一场风景都是我们爱的证明"
	},
	{
		t: 333.57,
		text: "就算如今，天各一方"
	},
	{
		t: 336.32,
		text: "把回忆拼好给你"
	}
];
function lyricState(t) {
	let i = -1;
	for (let k = 0; k < LYRICS.length; k++) if (LYRICS[k].t <= t + .06) i = k;
	if (i < 0) return {
		current: "",
		previous: ""
	};
	return {
		current: LYRICS[i].text,
		previous: i > 0 ? LYRICS[i - 1].text : ""
	};
}
function formatTime(t) {
	if (!Number.isFinite(t) || t < 0) return "0:00";
	return `${Math.floor(t / 60)}:${Math.floor(t % 60).toString().padStart(2, "0")}`;
}
function MemoryMv() {
	const canvasRef = (0, import_react.useRef)(null);
	const audioRef = (0, import_react.useRef)(null);
	const startedRef = (0, import_react.useRef)(false);
	const graphRef = (0, import_react.useRef)(null);
	const energyRef = (0, import_react.useRef)(0);
	const toggleRef = (0, import_react.useRef)(() => {});
	const [started, setStarted] = (0, import_react.useState)(false);
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const [ended, setEnded] = (0, import_react.useState)(false);
	const [time, setTime] = (0, import_react.useState)(0);
	const [duration, setDuration] = (0, import_react.useState)(381);
	const [hint, setHint] = (0, import_react.useState)("");
	const ensureGraph = () => {
		const audio = audioRef.current;
		if (!audio || graphRef.current) return graphRef.current;
		const AC = window.AudioContext || window.webkitAudioContext;
		if (!AC) return null;
		const ac = new AC();
		const src = ac.createMediaElementSource(audio);
		const an = ac.createAnalyser();
		an.fftSize = 64;
		src.connect(an);
		an.connect(ac.destination);
		const graph = {
			ac,
			an,
			data: new Uint8Array(new ArrayBuffer(an.frequencyBinCount))
		};
		graphRef.current = graph;
		return graph;
	};
	const begin = () => {
		const audio = audioRef.current;
		if (!audio) return;
		startedRef.current = true;
		setStarted(true);
		setEnded(false);
		setHint("");
		ensureGraph()?.ac.resume();
		audio.play().catch(() => setHint("再点一次，声音就会跟上"));
	};
	toggleRef.current = () => {
		const audio = audioRef.current;
		if (!audio) return;
		if (!startedRef.current) {
			begin();
			return;
		}
		if (audio.ended) {
			audio.currentTime = 0;
			setEnded(false);
			audio.play();
			return;
		}
		if (audio.paused) {
			ensureGraph()?.ac.resume();
			audio.play().catch(() => setHint("再点一次，声音就会跟上"));
		} else audio.pause();
	};
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		const audio = audioRef.current;
		if (!canvas || !audio) return;
		const ctx = canvas.getContext("2d", { alpha: false });
		if (!ctx) return;
		const params = new URLSearchParams(window.location.search);
		const jump = Number(params.get("t"));
		if (Number.isFinite(jump) && jump > 0) {
			const seek = () => {
				audio.currentTime = Math.min(jump, Number.isFinite(audio.duration) ? audio.duration : jump);
				startedRef.current = true;
				setStarted(true);
				setTime(audio.currentTime);
			};
			if (audio.readyState >= 1) seek();
			else audio.addEventListener("loadedmetadata", seek, { once: true });
		}
		const onMeta = () => {
			if (Number.isFinite(audio.duration)) setDuration(audio.duration);
		};
		const onPlay = () => {
			setPlaying(true);
			setEnded(false);
		};
		const onPause = () => setPlaying(false);
		const onEnd = () => {
			setPlaying(false);
			setEnded(true);
		};
		audio.addEventListener("loadedmetadata", onMeta);
		audio.addEventListener("play", onPlay);
		audio.addEventListener("pause", onPause);
		audio.addEventListener("ended", onEnd);
		let raf = 0;
		let posterT = 0;
		let last = performance.now();
		let lastUi = 0;
		const view = {
			w: 1,
			h: 1
		};
		const resize = () => {
			const parent = canvas.parentElement;
			if (!parent) return;
			const r = Math.min(2, window.devicePixelRatio || 1);
			const w = parent.clientWidth;
			const h = parent.clientHeight;
			canvas.width = Math.max(2, Math.floor(w * r));
			canvas.height = Math.max(2, Math.floor(h * r));
			ctx.setTransform(r, 0, 0, r, 0, 0);
			view.w = w;
			view.h = h;
		};
		resize();
		const ro = new ResizeObserver(resize);
		if (canvas.parentElement) ro.observe(canvas.parentElement);
		const loop = (now) => {
			const dt = Math.min(.05, (now - last) / 1e3);
			last = now;
			const playingNow = !audio.paused && !audio.ended && startedRef.current;
			let story = audio.currentTime || 0;
			let live = story;
			let poster = false;
			if (!startedRef.current) {
				posterT = Math.min(11.5, posterT + dt * 1.15);
				story = posterT;
				live = now / 1e3;
				poster = true;
			}
			const graph = graphRef.current;
			let energy = 0;
			if (graph && playingNow) {
				graph.an.getByteFrequencyData(graph.data);
				let sum = 0;
				for (let i = 0; i < graph.data.length; i++) sum += graph.data[i];
				energy = sum / graph.data.length / 255;
			}
			energyRef.current = energyRef.current * .82 + energy * .18;
			paint(ctx, view.w, view.h, story, live, energyRef.current, poster);
			if (now - lastUi > 120) {
				lastUi = now;
				if (startedRef.current) setTime(audio.currentTime || 0);
			}
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		const onKey = (e) => {
			if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
			if (e.code === "Space") {
				e.preventDefault();
				toggleRef.current();
			} else if (e.code === "ArrowRight") audio.currentTime = Math.min(audio.duration || 381, audio.currentTime + 5);
			else if (e.code === "ArrowLeft") audio.currentTime = Math.max(0, audio.currentTime - 5);
		};
		window.addEventListener("keydown", onKey);
		return () => {
			cancelAnimationFrame(raf);
			ro.disconnect();
			audio.removeEventListener("loadedmetadata", onMeta);
			audio.removeEventListener("play", onPlay);
			audio.removeEventListener("pause", onPause);
			audio.removeEventListener("ended", onEnd);
			window.removeEventListener("keydown", onKey);
		};
	}, []);
	const lyric = lyricState(started ? time : -1);
	const chapter = started ? chapterAt(time) : "前奏";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex h-dvh min-h-0 flex-col bg-bg text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "sr-only",
				children: "把回忆拼好给你"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative min-h-0 flex-1 bg-paper",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
						ref: canvasRef,
						className: "absolute inset-0 h-full w-full",
						onClick: () => toggleRef.current(),
						"aria-hidden": true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pointer-events-none absolute left-4 top-3 font-brush text-lg leading-none text-ink/80",
						children: "逐帧手绘"
					}),
					!started && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-x-0 bottom-0 flex justify-center px-5 pb-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "w-full max-w-md text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-serif text-sm tracking-widest text-muted",
									children: "逐帧手绘"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-brush text-5xl leading-none text-ink sm:text-6xl",
									children: "把回忆拼好给你"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 font-serif text-base text-ink",
									children: "王贰浪"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-serif text-sm text-muted",
									children: "用线条，一帧一帧把日子画回来"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: begin,
									className: "mt-5 inline-flex min-h-11 items-center justify-center bg-ink px-7 py-2 font-brush text-2xl text-paper",
									children: "开始放映"
								}),
								hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-sunset",
									children: hint
								}) : null
							]
						})
					}),
					started && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-paper via-paper/90 to-transparent px-4 pb-2 pt-10 text-center",
						children: [lyric.previous ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-serif text-sm text-muted",
							children: lyric.previous
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-serif text-sm text-muted",
							children: " "
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "lyric-line font-brush text-2xl leading-tight text-ink sm:text-4xl",
							children: lyric.current || " "
						}, lyric.current)]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shrink-0 border-t border-line bg-paper px-4 pt-1 pb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: "播放进度"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "seek",
						type: "range",
						min: 0,
						max: duration || 381,
						step: .1,
						value: Math.min(time, duration || 381),
						"aria-valuetext": formatTime(time),
						onChange: (e) => {
							const next = Number(e.target.value);
							const audio = audioRef.current;
							if (!audio) return;
							startedRef.current = true;
							setStarted(true);
							audio.currentTime = next;
							setTime(next);
							setEnded(false);
						}
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => toggleRef.current(),
							className: "inline-flex size-11 items-center justify-center rounded-full bg-ink text-paper",
							"aria-label": ended ? "重新放映" : playing ? "暂停" : "播放",
							children: ended ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-5" }) : playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "min-w-0 flex-1 truncate font-brush text-xl leading-none",
							children: chapter
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-serif text-sm tabular-nums text-muted",
							children: [
								formatTime(time),
								" / ",
								formatTime(duration)
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
				ref: audioRef,
				src: "/audio/song.mp3",
				preload: "auto",
				playsInline: true
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemoryMv, {});
}
//#endregion
export { Home as component };
