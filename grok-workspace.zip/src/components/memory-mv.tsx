import { useEffect, useRef, useState } from "react";
import { Pause, Play, RotateCcw } from "lucide-react";
import { chapterAt, paint } from "@/mv/film";
import { lyricState } from "@/mv/lyrics";

function formatTime(t: number) {
  if (!Number.isFinite(t) || t < 0) return "0:00";
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

type Graph = {
  ac: AudioContext;
  an: AnalyserNode;
  data: Uint8Array<ArrayBuffer>;
};

export function MemoryMv() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  const startedRef = useRef(false);
  const graphRef = useRef<Graph | null>(null);
  const energyRef = useRef(0);
  const toggleRef = useRef<() => void>(() => {});

  const [started, setStarted] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [ended, setEnded] = useState(false);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(381);
  const [hint, setHint] = useState("");

  const ensureGraph = () => {
    const audio = audioRef.current;
    if (!audio || graphRef.current) return graphRef.current;
    const AC =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return null;
    const ac = new AC();
    const src = ac.createMediaElementSource(audio);
    const an = ac.createAnalyser();
    an.fftSize = 64;
    src.connect(an);
    an.connect(ac.destination);
    const data = new Uint8Array(new ArrayBuffer(an.frequencyBinCount));
    const graph: Graph = { ac, an, data };
    graphRef.current = graph;
    return graph;
  };

  const begin = () => {
    const audio = audioRef.current;
    if (!audio) return;
    startedRef.current = true;
    setStarted(true);
    setEnded(false);
    setHint("");
    const graph = ensureGraph();
    void graph?.ac.resume();
    void audio.play().catch(() => setHint("再点一次，声音就会跟上"));
  };

  toggleRef.current = () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (!startedRef.current) {
      begin();
      return;
    }
    if (audio.ended) {
      audio.currentTime = 0;
      setEnded(false);
      void audio.play();
      return;
    }
    if (audio.paused) {
      const graph = ensureGraph();
      void graph?.ac.resume();
      void audio.play().catch(() => setHint("再点一次，声音就会跟上"));
    } else audio.pause();
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    const audio = audioRef.current;
    if (!canvas || !audio) return;
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) return;

    const params = new URLSearchParams(window.location.search);
    const jump = Number(params.get("t"));
    if (Number.isFinite(jump) && jump > 0) {
      const seek = () => {
        audio.currentTime = Math.min(jump, Number.isFinite(audio.duration) ? audio.duration : jump);
        startedRef.current = true;
        setStarted(true);
        setTime(audio.currentTime);
      };
      if (audio.readyState >= 1) seek();
      else audio.addEventListener("loadedmetadata", seek, { once: true });
    }

    const onMeta = () => {
      if (Number.isFinite(audio.duration)) setDuration(audio.duration);
    };
    const onPlay = () => {
      setPlaying(true);
      setEnded(false);
    };
    const onPause = () => setPlaying(false);
    const onEnd = () => {
      setPlaying(false);
      setEnded(true);
    };
    audio.addEventListener("loadedmetadata", onMeta);
    audio.addEventListener("play", onPlay);
    audio.addEventListener("pause", onPause);
    audio.addEventListener("ended", onEnd);

    let raf = 0;
    let posterT = 0;
    let last = performance.now();
    let lastUi = 0;
    const view = { w: 1, h: 1 };

    const resize = () => {
      const parent = canvas.parentElement;
      if (!parent) return;
      const r = Math.min(2, window.devicePixelRatio || 1);
      const w = parent.clientWidth;
      const h = parent.clientHeight;
      canvas.width = Math.max(2, Math.floor(w * r));
      canvas.height = Math.max(2, Math.floor(h * r));
      ctx.setTransform(r, 0, 0, r, 0, 0);
      view.w = w;
      view.h = h;
    };
    resize();
    const ro = new ResizeObserver(resize);
    if (canvas.parentElement) ro.observe(canvas.parentElement);

    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const playingNow = !audio.paused && !audio.ended && startedRef.current;
      let story = audio.currentTime || 0;
      let live = story;
      let poster = false;
      if (!startedRef.current) {
        posterT = Math.min(11.5, posterT + dt * 1.15);
        story = posterT;
        live = now / 1000;
        poster = true;
      }
      const graph = graphRef.current;
      let energy = 0;
      if (graph && playingNow) {
        graph.an.getByteFrequencyData(graph.data);
        let sum = 0;
        for (let i = 0; i < graph.data.length; i++) sum += graph.data[i];
        energy = sum / graph.data.length / 255;
      }
      energyRef.current = energyRef.current * 0.82 + energy * 0.18;
      paint(ctx, view.w, view.h, story, live, energyRef.current, poster);
      if (now - lastUi > 120) {
        lastUi = now;
        if (startedRef.current) setTime(audio.currentTime || 0);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    const onKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.code === "Space") {
        e.preventDefault();
        toggleRef.current();
      } else if (e.code === "ArrowRight") {
        audio.currentTime = Math.min(audio.duration || 381, audio.currentTime + 5);
      } else if (e.code === "ArrowLeft") {
        audio.currentTime = Math.max(0, audio.currentTime - 5);
      }
    };
    window.addEventListener("keydown", onKey);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      audio.removeEventListener("loadedmetadata", onMeta);
      audio.removeEventListener("play", onPlay);
      audio.removeEventListener("pause", onPause);
      audio.removeEventListener("ended", onEnd);
      window.removeEventListener("keydown", onKey);
    };
  }, []);

  const lyric = lyricState(started ? time : -1);
  const chapter = started ? chapterAt(time) : "前奏";

  return (
    <main className="flex h-dvh min-h-0 flex-col bg-bg text-ink">
      <h1 className="sr-only">把回忆拼好给你</h1>
      <div className="relative min-h-0 flex-1 bg-paper">
        <canvas
          ref={canvasRef}
          className="absolute inset-0 h-full w-full"
          onClick={() => toggleRef.current()}
          aria-hidden
        />
        {started ? (
          <p className="pointer-events-none absolute left-4 top-3 font-brush text-lg leading-none text-ink/80">
            逐帧手绘
          </p>
        ) : null}
        {!started && (
          <div className="absolute inset-x-0 bottom-0 flex justify-center px-5 pb-5">
            <div className="w-full max-w-md text-center">
              <p className="font-serif text-sm tracking-widest text-muted">逐帧手绘</p>
              <p className="mt-1 font-brush text-5xl leading-none text-ink sm:text-6xl">把回忆拼好给你</p>
              <p className="mt-3 font-serif text-base text-ink">王贰浪</p>
              <p className="mt-1 font-serif text-sm text-muted">用线条，一帧一帧把日子画回来</p>
              <button
                type="button"
                onClick={begin}
                className="mt-5 inline-flex min-h-11 items-center justify-center bg-ink px-7 py-2 font-brush text-2xl text-paper"
              >
                开始放映
              </button>
              {hint ? <p className="mt-2 text-sm text-sunset">{hint}</p> : null}
            </div>
          </div>
        )}
        {started && (
          <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-paper via-paper/90 to-transparent px-4 pb-2 pt-10 text-center">
            {lyric.previous ? (
              <p className="font-serif text-sm text-muted">{lyric.previous}</p>
            ) : (
              <p className="font-serif text-sm text-muted"> </p>
            )}
            <p key={lyric.current} className="lyric-line font-brush text-2xl leading-tight text-ink sm:text-4xl">
              {lyric.current || " "}
            </p>
          </div>
        )}
      </div>
      <div className="shrink-0 border-t border-line bg-paper px-4 pt-1 pb-3">
        <label className="block">
          <span className="sr-only">播放进度</span>
          <input
            className="seek"
            type="range"
            min={0}
            max={duration || 381}
            step={0.1}
            value={Math.min(time, duration || 381)}
            aria-valuetext={formatTime(time)}
            onChange={(e) => {
              const next = Number(e.target.value);
              const audio = audioRef.current;
              if (!audio) return;
              startedRef.current = true;
              setStarted(true);
              audio.currentTime = next;
              setTime(next);
              setEnded(false);
            }}
          />
        </label>
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => toggleRef.current()}
            className="inline-flex size-11 items-center justify-center rounded-full bg-ink text-paper"
            aria-label={ended ? "重新放映" : playing ? "暂停" : "播放"}
          >
            {ended ? <RotateCcw className="size-5" /> : playing ? <Pause className="size-5" /> : <Play className="size-5" />}
          </button>
          <p className="min-w-0 flex-1 truncate font-brush text-xl leading-none">{chapter}</p>
          <p className="font-serif text-sm tabular-nums text-muted">
            {formatTime(time)} / {formatTime(duration)}
          </p>
        </div>
        </div>
      <audio ref={audioRef} src="/audio/song.mp3" preload="auto" playsInline />
    </main>
  );
}
