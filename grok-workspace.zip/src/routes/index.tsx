import { createFileRoute } from "@tanstack/react-router";
import { MemoryMv } from "@/components/memory-mv";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <MemoryMv />;
}
