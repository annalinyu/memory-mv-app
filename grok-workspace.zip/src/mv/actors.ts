import {
  PAL,
  blot,
  brush,
  fillPoly,
  frameRect,
  oval,
  qbez,
  stroke,
  type Ctx,
  type Pt,
} from "./sketch";

export type Mood = "soft" | "smile" | "sad" | "shy" | "sleep";
export type Pose = "stand" | "walk" | "sit" | "reach" | "wave" | "hug" | "apart" | "pray";

export type PersonOpt = {
  x: number;
  y: number;
  s?: number;
  flip?: boolean;
  hair: "short" | "long";
  shirt: string;
  pants?: string;
  skirt?: boolean;
  mood: Mood;
  pose: Pose;
  phase?: number;
  reveal?: number;
  ribbon?: string;
};

function limb(ctx: Ctx, a: Pt, b: Pt, c: Pt, width: number, color: string, reveal: number, seed: number) {
  stroke(ctx, qbez(a, b, c, 7), { w: width, color, reveal, passes: 1, seed });
}

export function person(ctx: Ctx, p: PersonOpt) {
  const s = p.s ?? 1;
  const reveal = p.reveal ?? 1;
  if (reveal <= 0.02) return;
  const phase = p.phase ?? 0;
  const bob = p.pose === "walk" ? Math.sin(phase * 2) * 3 : Math.sin(phase * 0.6) * 1.2;
  const sit = p.pose === "sit";
  const hipY = sit ? -46 : -72;
  const neckY = hipY - 48;
  const headY = neckY - 28;
  const headR = 22;

  ctx.save();
  ctx.translate(p.x, p.y + bob * s);
  ctx.scale((p.flip ? -1 : 1) * s, s);
  ctx.globalAlpha = 1;

  blot(ctx, 2, 4, 34, 7, "rgba(70,50,30,0.45)", 0.28 * reveal);

  const sw = Math.sin(phase);
  const pants = p.pants ?? PAL.pants;

  const drawLeg = (side: number, seed: number) => {
    const hip: Pt = [side * 7, hipY];
    let foot: Pt;
    if (sit) foot = [side * 34, hipY + 6];
    else if (p.pose === "walk") {
      const lift = side === -1 ? (sw > 0 ? -Math.abs(sw) * 8 : 0) : sw < 0 ? -Math.abs(sw) * 8 : 0;
      foot = [side * 12 + (side === -1 ? -sw : sw) * 16, lift];
    } else foot = [side * 14, 0];
    const knee: Pt = [(hip[0] + foot[0]) / 2 + side * 2, (hip[1] + foot[1]) / 2 - (sit ? 2 : 8)];
    if (!p.skirt) limb(ctx, hip, knee, foot, 9, pants, reveal, seed);
    limb(ctx, hip, knee, foot, 1.7, PAL.ink, reveal, seed + 3);
    blot(ctx, foot[0], foot[1] + 1, sit ? 7 : 9, 4, PAL.ink, reveal);
  };

  if (p.skirt) {
    const hem = hipY + 36;
    fillPoly(
      ctx,
      [
        [-18, hipY + 2],
        [18, hipY + 2],
        [28, hem],
        [-28, hem],
      ],
      p.shirt,
      0.95 * reveal,
    );
    stroke(
      ctx,
      [
        [-18, hipY + 2],
        [-28, hem],
        [28, hem],
        [18, hipY + 2],
      ],
      { w: 1.7, reveal, seed: 9 },
    );
  } else {
    drawLeg(-1, 1);
    drawLeg(1, 2);
  }

  const torso: Pt[] = [
    [-24, hipY + 4],
    [-28, neckY + 6],
    [-12, neckY - 6],
    [12, neckY - 6],
    [26, neckY + 6],
    [22, hipY + 4],
  ];
  fillPoly(ctx, torso, p.shirt, 0.94 * reveal);
  stroke(ctx, [...torso, torso[0]], { w: 1.8, reveal, seed: 4 });
  stroke(
    ctx,
    [
      [0, neckY - 2],
      [-6, neckY + 14],
      [6, neckY + 14],
    ],
    { w: 1.3, color: PAL.inkSoft, reveal, seed: 5, a: 0.7 },
  );

  const arm = (side: number) => {
    const shoulder: Pt = [side * 18, neckY + 8];
    let elbow: Pt;
    let hand: Pt;
    const swing = Math.sin(phase + (side < 0 ? 0 : Math.PI));
    if (p.pose === "walk") {
      hand = [side * 14 + swing * 12, hipY + 8];
      elbow = [side * 24 + swing * 4, (shoulder[1] + hand[1]) / 2];
    } else if (p.pose === "reach" && side > 0) {
      elbow = [36, neckY];
      hand = [64, neckY - 16];
    } else if (p.pose === "wave" && side > 0) {
      elbow = [30, neckY - 18];
      hand = [34, neckY - 50];
    } else if (p.pose === "hug") {
      elbow = [side * 28, neckY + 2];
      hand = [34, neckY + 8];
    } else if (p.pose === "pray") {
      elbow = [side * 12, neckY + 18];
      hand = [side * 3, neckY + 10];
    } else if (p.pose === "apart") {
      elbow = [side * 20, hipY + 6];
      hand = [side * 12, hipY + 20];
    } else if (sit) {
      elbow = [side * 24, hipY + 10];
      hand = [side * 32, hipY + 22];
    } else {
      elbow = [side * 26, hipY + 4];
      hand = [side * 18, hipY + 24];
    }
    limb(ctx, shoulder, elbow, hand, 8, p.shirt, reveal, 10 + side);
    limb(ctx, shoulder, elbow, hand, 1.5, PAL.ink, reveal, 12 + side);
    blot(ctx, hand[0], hand[1], 5.5, 4.5, PAL.skin, reveal);
  };
  arm(-1);
  arm(1);

  if (p.hair === "long") {
    fillPoly(
      ctx,
      [
        [-headR + 2, headY - 4],
        [-26, headY + 20],
        [-22, hipY + 8],
        [22, hipY + 6],
        [26, headY + 18],
        [headR - 2, headY - 4],
      ],
      "#3a3128",
      reveal,
    );
  }

  blot(ctx, 0, headY, headR + 1, headR + 2, PAL.skin, reveal);
  oval(ctx, 0, headY, headR, headR + 1, { w: 1.8, reveal, seed: 20 });

  if (p.hair === "short") {
    fillPoly(
      ctx,
      [
        [-headR + 1, headY - 2],
        [-headR - 1, headY - 14],
        [-8, headY - headR - 4],
        [10, headY - headR - 2],
        [headR + 2, headY - 12],
        [headR, headY + 2],
        [6, headY - 4],
        [-4, headY + 1],
      ],
      "#3a3128",
      reveal,
    );
    stroke(
      ctx,
      qbez([-headR + 2, headY], [-6, headY - headR - 6], [headR, headY - 2], 8),
      { w: 1.6, reveal, seed: 21 },
    );
  } else {
    stroke(
      ctx,
      qbez([-16, headY - 6], [0, headY - 2], [14, headY - 8], 6),
      { w: 1.5, reveal, seed: 22, a: 0.85 },
    );
    stroke(ctx, qbez([-18, headY - 8], [-24, headY + 16], [-16, hipY], 6), {
      w: 1.4,
      reveal,
      seed: 23,
    });
    stroke(ctx, qbez([16, headY - 6], [24, headY + 18], [14, hipY - 4], 6), {
      w: 1.4,
      reveal,
      seed: 24,
    });
    if (p.ribbon) {
      blot(ctx, 18, headY - 8, 6, 5, p.ribbon, reveal);
      stroke(ctx, qbez([18, headY - 4], [26, headY + 6], [20, headY + 16], 4), {
        w: 1.4,
        color: p.ribbon,
        reveal,
        seed: 25,
      });
    }
  }

  const eye = (x: number, sad: boolean) => {
    const y = headY - 1;
    if (p.mood === "sleep") {
      stroke(ctx, [[x - 5, y], [x + 4, y + 1]], { w: 1.5, reveal, seed: x });
      return;
    }
    if (p.mood === "smile") {
      stroke(ctx, qbez([x - 5, y + 1], [x, y - 3], [x + 5, y + 1], 4), { w: 1.5, reveal, seed: x });
      return;
    }
    blot(ctx, x, y + (p.mood === "shy" ? 2 : 0), 1.7, 1.7, PAL.ink, reveal);
    if (sad || p.mood === "sad") {
      stroke(ctx, [[x - 5, y - 6], [x + 4, y - 4]], { w: 1.3, reveal, seed: x + 2 });
    }
  };
  eye(-7, p.mood === "sad");
  eye(7, p.mood === "sad");

  if (p.mood === "smile" || p.mood === "shy") {
    blot(ctx, -12, headY + 6, 5, 3, PAL.blush, 0.55 * reveal);
    blot(ctx, 12, headY + 6, 5, 3, PAL.blush, 0.55 * reveal);
  }
  if (p.mood === "sad") {
    const drip = 4 + Math.sin(phase) * 1.5;
    stroke(ctx, [[8, headY + 6], [9, headY + 6 + drip]], { w: 1.3, color: PAL.blue, reveal, seed: 30 });
  }

  const my = headY + 10;
  if (p.mood === "smile") {
    stroke(ctx, qbez([-5, my], [0, my + 5], [6, my], 4), { w: 1.4, reveal, seed: 31 });
  } else if (p.mood === "sad") {
    stroke(ctx, qbez([-5, my + 3], [0, my - 1], [5, my + 3], 4), { w: 1.4, reveal, seed: 32 });
  } else if (p.mood !== "sleep") {
    stroke(ctx, [[-3, my], [4, my + 1]], { w: 1.3, reveal, seed: 33 });
  }

  ctx.restore();
}

export function heart(ctx: Ctx, x: number, y: number, s: number, color: string, reveal = 1) {
  if (reveal <= 0.02) return;
  const pts: Pt[] = [];
  for (let i = 0; i <= 28; i++) {
    const t = (i / 28) * Math.PI * 2;
    const hx = 16 * Math.sin(t) ** 3;
    const hy = -(13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t));
    pts.push([x + hx * s, y + hy * s]);
  }
  fillPoly(ctx, pts, color, 0.92 * reveal);
  stroke(ctx, pts, { w: 1.4, reveal, seed: 40, a: 0.75 });
}

export function bird(ctx: Ctx, x: number, y: number, s: number, flap: number, reveal = 1, fly = 0) {
  if (reveal <= 0.02) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(fly);
  ctx.scale(s, s);
  const wing = Math.sin(flap) * 14;
  stroke(ctx, qbez([-18, 2], [-26, -8 - wing], [-6, -2], 5), { w: 1.7, reveal, seed: 50 });
  stroke(ctx, qbez([6, -2], [20, -10 - wing], [16, 3], 5), { w: 1.7, reveal, seed: 51 });
  fillPoly(
    ctx,
    [
      [-8, -4],
      [8, -6],
      [12, 0],
      [4, 6],
      [-10, 5],
    ],
    PAL.ink,
    reveal,
  );
  stroke(ctx, qbez([-12, 2], [-20, 8], [-16, 0], 4), { w: 1.5, reveal, seed: 52 });
  blot(ctx, 10, -2, 2, 2, PAL.sun, reveal);
  stroke(ctx, [[10, 0], [16, 1]], { w: 1.4, color: PAL.sunset, reveal, seed: 53 });
  ctx.restore();
}

export function leaf(ctx: Ctx, x: number, y: number, s: number, rot: number, reveal = 1) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.scale(s, s);
  const pts = qbez([-8, 2], [0, -14], [10, 0], 6).concat(qbez([10, 0], [0, 8], [-8, 2], 5));
  fillPoly(ctx, pts, PAL.leaf, 0.85 * reveal);
  stroke(ctx, pts, { w: 1.1, color: PAL.leafDeep, reveal, seed: x });
  ctx.restore();
}

export function flower(ctx: Ctx, x: number, y: number, s: number, open: number, color: string) {
  const o = Math.max(0.05, open);
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * Math.PI * 2 + 0.4;
    blot(ctx, x + Math.cos(a) * 7 * s * o, y + Math.sin(a) * 7 * s * o, 5.5 * s, 8 * s, color, 0.75);
  }
  blot(ctx, x, y, 3.2 * s, 3.2 * s, PAL.sun, 0.95);
  stroke(ctx, [[x, y + 6 * s], [x, y + 22 * s]], { w: 1.3, color: PAL.leafDeep, reveal: open, seed: y });
}

export function pot(ctx: Ctx, x: number, y: number, growth: number, reveal = 1) {
  if (reveal <= 0.02) return;
  fillPoly(
    ctx,
    [
      [-18, -8],
      [18, -8],
      [14, 16],
      [-14, 16],
    ].map(([px, py]) => [x + px, y + py]),
    PAL.sunset,
    0.85 * reveal,
  );
  stroke(
    ctx,
    [
      [x - 18, y - 8],
      [x + 18, y - 8],
      [x + 14, y + 16],
      [x - 14, y + 16],
      [x - 18, y - 8],
    ],
    { w: 1.6, reveal, seed: 60 },
  );
  const g = Math.max(0, growth);
  stroke(ctx, [[x, y - 8], [x + 2, y - 8 - 36 * g]], { w: 1.6, color: PAL.leafDeep, reveal, seed: 61 });
  leaf(ctx, x - 10 * g, y - 20 - 10 * g, 0.8, -0.8, reveal * g);
  leaf(ctx, x + 12 * g, y - 28 * g, 0.85, 0.6, reveal * g);
  if (g > 0.65) {
    blot(ctx, x + 2, y - 8 - 40 * g, 5, 5, PAL.sun, reveal);
    heart(ctx, x + 16, y - 46 * g, 0.28, PAL.gold, reveal * (g - 0.4));
  }
}

export function starShape(ctx: Ctx, x: number, y: number, r: number, color: string, reveal = 1) {
  if (reveal <= 0.02) return;
  const pts: Pt[] = [];
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * Math.PI * 2 - Math.PI / 2;
    const rad = i % 2 === 0 ? r : r * 0.42;
    pts.push([x + Math.cos(a) * rad, y + Math.sin(a) * rad]);
  }
  fillPoly(ctx, pts, color, 0.9 * reveal);
  stroke(ctx, [...pts, pts[0]], { w: 1.1, reveal, seed: x, a: 0.65 });
}

export function moon(ctx: Ctx, x: number, y: number, r: number, reveal = 1) {
  if (reveal <= 0.02) return;
  blot(ctx, x, y, r * 1.15, r * 1.15, "rgba(244,235,218,0.45)", 0.55 * reveal);
  ctx.save();
  ctx.fillStyle = "#f7f1e4";
  ctx.globalAlpha = reveal;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 0.45 * reveal;
  ctx.fillStyle = "#e7dcc4";
  ctx.beginPath();
  ctx.arc(x - r * 0.25, y - r * 0.1, r * 0.22, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(x + r * 0.28, y + r * 0.22, r * 0.14, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  oval(ctx, x, y, r, r, { w: 1.6, color: PAL.inkSoft, reveal, a: 0.45, seed: 70 });
}

export function sun(ctx: Ctx, x: number, y: number, r: number, reveal = 1) {
  blot(ctx, x, y, r * 1.8, r * 1.5, PAL.sun, 0.55 * reveal);
  ctx.save();
  ctx.globalAlpha = reveal;
  ctx.fillStyle = "#f6c56a";
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * Math.PI * 2;
    stroke(
      ctx,
      [
        [x + Math.cos(a) * (r + 6), y + Math.sin(a) * (r + 6)],
        [x + Math.cos(a) * (r + 18), y + Math.sin(a) * (r + 16)],
      ],
      { w: 1.6, color: PAL.sunset, reveal, seed: i, a: 0.8 },
    );
  }
}

export function rain(ctx: Ctx, w: number, h: number, live: number, ground: number, amount = 1) {
  const count = Math.floor(64 * amount);
  for (let i = 0; i < count; i++) {
    const x = ((i * 97) % (w + 60)) - 30;
    const speed = 240 + (i % 6) * 36;
    const y0 = ((i * 53 + live * speed) % (ground + 50)) - 40;
    const len = 12 + (i % 5) * 3;
    stroke(ctx, [[x, y0], [x - 5, y0 + len]], {
      w: 1.15,
      color: PAL.blueDeep,
      a: 0.32,
      passes: 1,
      seed: i,
    });
  }
}

export function fallingLeaves(ctx: Ctx, w: number, ground: number, live: number, n = 16) {
  for (let i = 0; i < n; i++) {
    const x = ((i * 131 + live * (18 + (i % 5) * 6)) % (w + 40)) - 20;
    const y = ((i * 77 + live * (26 + (i % 4) * 8)) % (ground + 30)) - 16;
    leaf(ctx, x, y, 0.55 + (i % 3) * 0.15, live * 0.8 + i, 1);
  }
}

export function crowd(ctx: Ctx, w: number, gy: number, live: number, reveal = 1) {
  for (let i = 0; i < 8; i++) {
    const x = ((i * 140 - live * 18) % (w + 80)) - 40;
    const h = 46 + (i % 3) * 10;
    ctx.save();
    ctx.globalAlpha = 0.28 * reveal;
    ctx.fillStyle = PAL.ink;
    ctx.beginPath();
    ctx.ellipse(x, gy - h - 8, 7, 8, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillRect(x - 8, gy - h, 16, h);
    ctx.restore();
  }
}

export function pencilTool(ctx: Ctx, x: number, y: number, angle: number, reveal = 1) {
  if (reveal <= 0.02) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle);
  ctx.globalAlpha = reveal;
  ctx.fillStyle = PAL.gold;
  ctx.fillRect(-5, -46, 10, 64);
  ctx.fillStyle = PAL.ink;
  ctx.beginPath();
  ctx.moveTo(-5, -46);
  ctx.lineTo(0, -62);
  ctx.lineTo(5, -46);
  ctx.fill();
  ctx.fillStyle = "#3a342c";
  ctx.beginPath();
  ctx.moveTo(-2, -56);
  ctx.lineTo(0, -62);
  ctx.lineTo(2, -56);
  ctx.fill();
  ctx.restore();
}

export function polaroid(
  ctx: Ctx,
  x: number,
  y: number,
  rot: number,
  sc: number,
  reveal: number,
  draw: () => void,
) {
  if (reveal <= 0.02) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.scale(sc, sc);
  ctx.globalAlpha = reveal;
  ctx.fillStyle = PAL.white;
  ctx.fillRect(-46, -58, 92, 112);
  ctx.strokeStyle = PAL.inkSoft;
  ctx.lineWidth = 1.2;
  ctx.strokeRect(-46, -58, 92, 112);
  ctx.beginPath();
  ctx.rect(-40, -52, 80, 68);
  ctx.clip();
  ctx.globalAlpha = 1;
  draw();
  ctx.restore();
}

export function clock(ctx: Ctx, x: number, y: number, r: number, live: number, reveal = 1) {
  oval(ctx, x, y, r, r, { w: 1.7, reveal, seed: 80 });
  blot(ctx, x, y, 2, 2, PAL.ink, reveal);
  const hour = live * 0.45;
  const min = live * 2.4;
  stroke(
    ctx,
    [
      [x, y],
      [x + Math.sin(hour) * r * 0.45, y - Math.cos(hour) * r * 0.45],
    ],
    { w: 1.8, reveal, seed: 81 },
  );
  stroke(
    ctx,
    [
      [x, y],
      [x + Math.sin(min) * r * 0.72, y - Math.cos(min) * r * 0.72],
    ],
    { w: 1.3, reveal, seed: 82 },
  );
}

export function openPalm(ctx: Ctx, x: number, y: number, s: number, reveal = 1) {
  if (reveal <= 0.02) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  blot(ctx, 0, 8, 48, 34, PAL.skin, 0.95 * reveal);
  oval(ctx, 0, 10, 46, 32, { w: 1.8, reveal, seed: 90 });
  const fingers = [-30, -12, 6, 24];
  fingers.forEach((fx, i) => {
    limb(ctx, [fx, -8], [fx + 2, -40], [fx - 2, -68 - (i === 2 ? 6 : 0)], 7, PAL.skin, reveal, 91 + i);
    limb(ctx, [fx, -8], [fx + 2, -40], [fx - 2, -68 - (i === 2 ? 6 : 0)], 1.4, PAL.ink, reveal, 95 + i);
  });
  limb(ctx, [36, 10], [58, -8], [52, -36], 7, PAL.skin, reveal, 100);
  limb(ctx, [36, 10], [58, -8], [52, -36], 1.4, PAL.ink, reveal, 101);
  ctx.restore();
}

export function umbrella(ctx: Ctx, x: number, y: number, s: number, color: string, reveal = 1) {
  if (reveal <= 0.02) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  blot(ctx, 0, -4, 70, 28, color, 0.55 * reveal);
  stroke(ctx, qbez([-74, 0], [0, -46], [74, 0], 10), { w: 2, reveal, seed: 110 });
  stroke(ctx, [[-74, 0], [74, 0]], { w: 1.6, reveal, seed: 111 });
  stroke(ctx, [[0, 0], [0, 78]], { w: 1.8, reveal, seed: 112 });
  stroke(ctx, qbez([0, 78], [10, 86], [0, 92], 4), { w: 1.6, reveal, seed: 113 });
  for (let i = -2; i <= 2; i++) {
    stroke(ctx, [[i * 24, 0], [i * 16, -22]], { w: 1.1, color: PAL.inkSoft, reveal, a: 0.6, seed: 114 + i });
  }
  ctx.restore();
}

export function kite(ctx: Ctx, x: number, y: number, s: number, reveal = 1) {
  if (reveal <= 0.02) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  fillPoly(
    ctx,
    [
      [0, -28],
      [20, 0],
      [0, 32],
      [-20, 0],
    ],
    PAL.sunset,
    0.85 * reveal,
  );
  stroke(
    ctx,
    [
      [0, -28],
      [20, 0],
      [0, 32],
      [-20, 0],
      [0, -28],
    ],
    { w: 1.4, reveal, seed: 120 },
  );
  stroke(ctx, [[0, -28], [0, 32]], { w: 1, color: PAL.inkSoft, reveal, seed: 121 });
  stroke(ctx, qbez([0, 32], [6, 48], [-2, 64], 4), { w: 1.2, reveal, seed: 122 });
  blot(ctx, 4, 52, 4, 3, PAL.gold, reveal);
  blot(ctx, -3, 62, 3, 2.4, PAL.blue, reveal);
  ctx.restore();
}

export function ghost(ctx: Ctx, x: number, y: number, s: number, reveal = 1) {
  if (reveal <= 0.02) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  fillPoly(
    ctx,
    [
      [-18, -10],
      [-16, -28],
      [0, -36],
      [16, -28],
      [18, -8],
      [12, 8],
      [6, -2],
      [0, 10],
      [-6, -2],
      [-12, 8],
    ],
    PAL.white,
    0.95 * reveal,
  );
  stroke(
    ctx,
    qbez([-18, -6], [0, -40], [18, -6], 8).concat([
      [12, 8],
      [4, -2],
      [-2, 10],
      [-14, 4],
    ]),
    { w: 1.5, reveal, seed: 130 },
  );
  blot(ctx, -6, -16, 2, 2, PAL.ink, reveal);
  blot(ctx, 6, -16, 2, 2.4, PAL.ink, reveal);
  blot(ctx, -8, -8, 4, 2.5, PAL.blush, 0.6 * reveal);
  blot(ctx, 8, -8, 4, 2.5, PAL.blush, 0.6 * reveal);
  ctx.restore();
}

export function bug(ctx: Ctx, x: number, y: number, s: number, reveal = 1) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  fillPoly(
    ctx,
    [
      [-10, 0],
      [0, -6],
      [12, 0],
      [0, 6],
    ],
    PAL.leaf,
    reveal,
  );
  stroke(ctx, qbez([-12, 0], [0, -8], [14, 0], 5), { w: 1.2, color: PAL.leafDeep, reveal, seed: 140 });
  blot(ctx, 12, -1, 3, 3, PAL.ink, reveal);
  stroke(ctx, [[-2, -4], [-8, -12]], { w: 1, reveal, seed: 141 });
  stroke(ctx, [[2, -4], [6, -12]], { w: 1, reveal, seed: 142 });
  ctx.restore();
}

export function letter(ctx: Ctx, x: number, y: number, w: number, h: number, reveal = 1) {
  if (reveal <= 0.02) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.fillStyle = PAL.white;
  ctx.globalAlpha = reveal;
  ctx.fillRect(-w / 2, -h / 2, w, h);
  ctx.restore();
  frameRect(ctx, x - w / 2, y - h / 2, w, h, reveal, PAL.inkSoft, 1.4);
  stroke(
    ctx,
    [
      [x - w / 2, y - h / 2],
      [x, y],
      [x + w / 2, y - h / 2],
    ],
    { w: 1.2, color: PAL.inkSoft, reveal, seed: 150 },
  );
  heart(ctx, x, y + h * 0.18, 0.28, PAL.rose, reveal);
}

export function phone(ctx: Ctx, x: number, y: number, s: number, missed: boolean, reveal = 1) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  ctx.globalAlpha = reveal;
  ctx.fillStyle = PAL.ink;
  roundBox(ctx, -10, -18, 20, 36, 3);
  ctx.fillStyle = missed ? "#d7e4ea" : "#243044";
  ctx.fillRect(-7, -14, 14, 24);
  ctx.restore();
  if (missed) {
    stroke(ctx, qbez([x + 8 * s, y - 8 * s], [x + 16 * s, y - 16 * s], [x + 8 * s, y - 22 * s], 4), {
      w: 1.3,
      color: PAL.rose,
      reveal,
      seed: 160,
    });
  }
}

function roundBox(ctx: Ctx, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
  ctx.fill();
}

export function tv(ctx: Ctx, x: number, y: number, s: number, live: number, reveal = 1) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  ctx.globalAlpha = reveal;
  ctx.fillStyle = "#3a342c";
  ctx.fillRect(-46, -32, 92, 58);
  const glow = 0.35 + Math.sin(live * 7) * 0.08;
  ctx.globalAlpha = reveal * (0.7 + glow);
  ctx.fillStyle = "#f2d7a2";
  ctx.fillRect(-40, -26, 80, 46);
  ctx.restore();
  blot(ctx, x, y - 4 * s, 50 * s, 24 * s, PAL.sun, 0.18 * reveal);
}

export function blocks(ctx: Ctx, x: number, y: number, reveal = 1) {
  const cols = [
    { dx: -28, h: 16, c: PAL.sunset },
    { dx: -8, h: 28, c: PAL.blue },
    { dx: 12, h: 20, c: PAL.gold },
    { dx: 30, h: 12, c: PAL.leaf },
  ];
  cols.forEach((b, i) => {
    const rv = Math.max(0, reveal * 4 - i);
    ctx.save();
    ctx.globalAlpha = Math.min(1, rv);
    ctx.fillStyle = b.c;
    ctx.fillRect(x + b.dx, y - b.h, 16, b.h);
    ctx.restore();
    frameRect(ctx, x + b.dx, y - b.h, 16, b.h, Math.min(1, rv), PAL.ink, 1.2);
  });
}

export function firework(ctx: Ctx, x: number, y: number, live: number, born: number, color: string) {
  const age = live - born;
  if (age < 0 || age > 1.7) return;
  const u = age / 1.7;
  const n = 22;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2 + i * 0.2;
    const dist = u * (54 + (i % 4) * 10);
    const px = x + Math.cos(a) * dist;
    const py = y + Math.sin(a) * dist + u * u * 26;
    stroke(
      ctx,
      [
        [px, py],
        [px - Math.cos(a) * 7, py - Math.sin(a) * 7 + 2],
      ],
      { w: 1.5, color, a: (1 - u) * (1 - u), passes: 1, seed: i },
    );
  }
}

export function scrap(
  ctx: Ctx,
  x: number,
  y: number,
  size: number,
  rot: number,
  reveal: number,
  tint: string,
  mark: (ctx: Ctx, s: number) => void,
) {
  if (reveal <= 0.02) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.globalAlpha = reveal;
  ctx.fillStyle = PAL.white;
  const s = size / 2;
  ctx.beginPath();
  ctx.moveTo(-s, -s);
  ctx.lineTo(s * 0.35, -s);
  ctx.arc(s * 0.35, -s + s * 0.28, s * 0.28, -Math.PI / 2, Math.PI / 2, true);
  ctx.lineTo(s, -s + s * 0.55);
  ctx.lineTo(s, s);
  ctx.lineTo(-s, s);
  ctx.closePath();
  ctx.fill();
  ctx.save();
  ctx.clip();
  ctx.globalAlpha = 0.45 * reveal;
  ctx.fillStyle = tint;
  ctx.fillRect(-s, -s, size, size);
  ctx.globalAlpha = 1;
  mark(ctx, s);
  ctx.restore();
  ctx.globalAlpha = reveal;
  ctx.strokeStyle = PAL.inkSoft;
  ctx.lineWidth = 1.3;
  ctx.stroke();
  ctx.restore();
}

export function paperFlower(ctx: Ctx, x: number, y: number, s: number, open: number) {
  ctx.save();
  ctx.translate(x, y);
  const petals = 6;
  for (let i = 0; i < petals; i++) {
    ctx.save();
    ctx.rotate((i / petals) * Math.PI * 2);
    ctx.scale(s, s);
    const len = 8 + open * 18;
    fillPoly(
      ctx,
      [
        [0, 0],
        [-6, -len * 0.6],
        [0, -len],
        [6, -len * 0.6],
      ],
      i % 2 ? PAL.blush : PAL.white,
      0.9,
    );
    stroke(
      ctx,
      [
        [0, 0],
        [-6, -len * 0.6],
        [0, -len],
        [6, -len * 0.6],
        [0, 0],
      ],
      { w: 1.1, seed: i },
    );
    ctx.restore();
  }
  blot(ctx, 0, 0, 4 * s, 4 * s, PAL.sun, 1);
  ctx.restore();
}

export function bow(ctx: Ctx, x: number, y: number, s: number, reveal = 1) {
  if (reveal <= 0.02) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  fillPoly(ctx, [[0, 0], [-18, -12], [-28, 0], [-16, 10]], PAL.rose, reveal);
  fillPoly(ctx, [[0, 0], [18, -12], [28, 0], [16, 10]], PAL.rose, reveal);
  blot(ctx, 0, 1, 5, 4, PAL.rose, reveal);
  stroke(ctx, [[-8, 6], [-14, 22]], { w: 1.5, color: PAL.rose, reveal, seed: 170 });
  stroke(ctx, [[8, 6], [14, 22]], { w: 1.5, color: PAL.rose, reveal, seed: 171 });
  ctx.restore();
}

export function hills(
  ctx: Ctx,
  w: number,
  h: number,
  base: number,
  layers: { y: number; amp: number; color: string; seed: number }[],
) {
  for (const L of layers) {
    const pts: Pt[] = [[-30, h + 20]];
    for (let x = -30; x <= w + 30; x += 28) {
      pts.push([
        x,
        L.y + Math.sin(x * 0.007 + L.seed) * L.amp + Math.sin(x * 0.018 + L.seed * 2) * L.amp * 0.35,
      ]);
    }
    pts.push([w + 30, h + 20]);
    fillPoly(ctx, pts, L.color, 1);
    const ridge = pts.slice(1, -1);
    stroke(ctx, ridge, { w: 1.4, color: PAL.inkSoft, a: 0.35, seed: L.seed, passes: 1 });
  }
  void base;
}

export function caption(ctx: Ctx, text: string, x: number, y: number, size: number, reveal: number) {
  brush(ctx, text, x, y, size, PAL.ink, reveal);
}
