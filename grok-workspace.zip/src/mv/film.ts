import {
  bird,
  blocks,
  bow,
  bug,
  clock,
  crowd,
  fallingLeaves,
  firework,
  flower,
  ghost,
  heart,
  hills,
  kite,
  letter,
  moon,
  openPalm,
  paperFlower,
  pencilTool,
  person,
  phone,
  polaroid,
  pot,
  rain,
  scrap,
  starShape,
  sun,
  tv,
  umbrella,
} from "./actors";
import {
  PAL,
  blot,
  brush,
  clamp,
  fillPoly,
  frameRect,
  lerp,
  oval,
  paperGrain,
  revealAt,
  setFrameLive,
  smooth,
  stroke,
  vignette,
  type Ctx,
} from "./sketch";

export type Tone = "day" | "dawn" | "dusk" | "night";
export type SceneId =
  | "intro"
  | "keepsake"
  | "stars"
  | "street"
  | "knowyou"
  | "dawn"
  | "rain"
  | "days"
  | "rift"
  | "spark"
  | "grow"
  | "moon"
  | "pieces"
  | "coda";

export type Cue = { id: SceneId; t0: number; name: string; tone?: Tone };

export const CUES: Cue[] = [
  { id: "intro", t0: 0, name: "前奏" },
  { id: "keepsake", t0: 27.48, name: "收集", tone: "day" },
  { id: "stars", t0: 54.87, name: "星空" },
  { id: "street", t0: 65.25, name: "人海" },
  { id: "knowyou", t0: 79.14, name: "关于你" },
  { id: "dawn", t0: 95.68, name: "黎明" },
  { id: "keepsake", t0: 102.7, name: "回忆", tone: "dawn" },
  { id: "rain", t0: 139.2, name: "雨后" },
  { id: "days", t0: 151.09, name: "日常" },
  { id: "rift", t0: 163.49, name: "裂缝" },
  { id: "spark", t0: 174.99, name: "烟花" },
  { id: "keepsake", t0: 186.38, name: "回忆", tone: "dusk" },
  { id: "grow", t0: 209.87, name: "长大" },
  { id: "moon", t0: 241.28, name: "月亮" },
  { id: "keepsake", t0: 267.2, name: "回忆", tone: "night" },
  { id: "pieces", t0: 291.32, name: "拼好" },
  { id: "coda", t0: 339.32, name: "给你" },
];

export function chapterAt(t: number) {
  let name = CUES[0].name;
  for (const c of CUES) if (c.t0 <= t) name = c.name;
  return name;
}

type Frame = {
  ctx: Ctx;
  w: number;
  h: number;
  t: number;
  live: number;
  local: number;
  span: number;
  energy: number;
  poster: boolean;
  tone: Tone;
};

function groundY(h: number) {
  const raw = Math.min(h * 0.7, h - 64);
  return Math.max(h * 0.42, Math.min(raw, h * 0.78));
}

function peopleScale(h: number, gy: number) {
  return Math.min(1.12, Math.max(0.48, (gy - 8) / 210));
}

function overscan(ctx: Ctx, w: number, h: number, painter: (c: CanvasGradient) => void) {
  const g = ctx.createLinearGradient(0, 0, 0, h);
  painter(g);
  ctx.fillStyle = g;
  ctx.fillRect(-50, -50, w + 100, h + 100);
}

function floor(ctx: Ctx, w: number, h: number, gy: number, color: string) {
  ctx.fillStyle = color;
  ctx.fillRect(-40, gy, w + 80, h - gy + 40);
  stroke(ctx, [[-20, gy], [w * 0.3, gy + 2], [w * 0.7, gy - 1], [w + 20, gy + 2]], {
    w: 1.6,
    color: PAL.inkSoft,
    a: 0.45,
    seed: 3,
  });
}

function stars(ctx: Ctx, w: number, horizon: number, live: number, n = 36) {
  for (let i = 0; i < n; i++) {
    const x = (i * 137) % w;
    const y = (i * 89) % Math.max(20, horizon * 0.86);
    const tw = 0.35 + Math.sin(live * 2 + i) * 0.35;
    if (i % 7 === 0) starShape(ctx, x, y, 4 + (i % 3), PAL.gold, tw);
    else {
      ctx.save();
      ctx.globalAlpha = tw;
      ctx.fillStyle = "#f4ebda";
      ctx.fillRect(x, y, 1.6, 1.6);
      ctx.restore();
    }
  }
}

function margin(ctx: Ctx, h: number) {
  ctx.save();
  ctx.strokeStyle = "rgba(201,107,107,0.35)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(28, 0);
  ctx.lineTo(28, h);
  ctx.stroke();
  ctx.restore();
}

function windowFrame(ctx: Ctx, x: number, y: number, w: number, h: number, reveal: number) {
  frameRect(ctx, x, y, w, h, reveal, PAL.ink, 2.4);
  const mull = clamp(reveal * 2 - 1);
  stroke(ctx, [[x + w / 2, y], [x + w / 2, y + h]], { w: 1.8, reveal: mull, seed: 8 });
  stroke(ctx, [[x, y + h * 0.42], [x + w, y + h * 0.42]], { w: 1.8, reveal: mull, seed: 9 });
}

function photoInner(ctx: Ctx, kind: number) {
  if (kind === 0) {
    ctx.fillStyle = "#d5e4ee";
    ctx.fillRect(-40, -52, 80, 68);
    rain(ctx, 80, 68, 2, 60, 0.4);
  } else if (kind === 1) {
    ctx.fillStyle = "#f6e7c8";
    ctx.fillRect(-40, -52, 80, 68);
    bird(ctx, 0, 8, 1.3, 1, 1);
  } else if (kind === 2) {
    ctx.fillStyle = "#f3d2b0";
    ctx.fillRect(-40, -52, 80, 68);
    sun(ctx, 18, -20, 10, 1);
  } else if (kind === 3) {
    ctx.fillStyle = "#e7f0ea";
    ctx.fillRect(-40, -52, 80, 68);
    heart(ctx, 0, -8, 1.1, PAL.rose, 1);
  } else {
    ctx.fillStyle = "#243044";
    ctx.fillRect(-40, -52, 80, 68);
    moon(ctx, 8, -10, 14, 1);
  }
}

function intro(f: Frame) {
  const { ctx, w, h, live, local, poster } = f;
  overscan(ctx, w, h, (g) => {
    g.addColorStop(0, "#f7f1e6");
    g.addColorStop(1, PAL.paper);
  });
  margin(ctx, h);
  const ww = Math.min(w * 0.42, 380);
  const wh = ww * 0.68;
  const x = w / 2 - ww / 2;
  const y = h * 0.1;
  const rv = revealAt(local, 0.6, 7);
  ctx.fillStyle = "#e7eef2";
  ctx.globalAlpha = clamp(rv);
  ctx.fillRect(x, y, ww, wh);
  ctx.globalAlpha = 1;
  windowFrame(ctx, x, y, ww, wh, rv);
  if (local > 6) rain(ctx, w, y + wh, live, y + wh, clamp((local - 6) / 4));
  const pr = revealAt(local, 8, 2);
  person(ctx, {
    x: w / 2 - ww * 0.12,
    y: y + wh * 0.78,
    s: peopleScale(h, h) * 0.38,
    hair: "short",
    shirt: PAL.jacket,
    mood: "soft",
    pose: "stand",
    phase: live,
    reveal: pr,
  });
  person(ctx, {
    x: w / 2 + ww * 0.12,
    y: y + wh * 0.78,
    s: peopleScale(h, h) * 0.38,
    flip: true,
    hair: "long",
    shirt: PAL.shirt,
    skirt: true,
    mood: "soft",
    pose: "stand",
    ribbon: PAL.sunset,
    phase: live,
    reveal: pr,
  });
  const lead = revealAt(local, 0.4, 0.4);
  const px = x + ((Math.floor(clamp(local / 2) * 4) % 4) / 3) * ww;
  const py = y + (clamp(local / 8) > 0.5 ? wh : 8);
  pencilTool(ctx, local < 9 ? px : x + ww - 10, local < 9 ? py : y + wh - 8, -0.7, lead);
  if (!poster) {
    const tr = revealAt(local, 14, 5);
    const size = Math.min(w * 0.078, 68);
    ctx.save();
    ctx.beginPath();
    ctx.rect(w / 2 - size * 5, h * 0.78 - size, size * 10 * tr, size * 2.2);
    ctx.clip();
    brush(ctx, "把回忆拼好给你", w / 2, h * 0.78, size, PAL.ink, 1);
    ctx.restore();
    brush(ctx, "王贰浪", w / 2, h * 0.78 + size * 0.85, size * 0.38, PAL.inkSoft, clamp(tr * 1.4 - 0.3));
  }
}

function keepsake(f: Frame) {
  const { ctx, w, h, live, local, tone } = f;
  const gy = groundY(h);
  const night = tone === "night";
  const dawn = tone === "dawn";
  const dusk = tone === "dusk";
  if (night) {
    overscan(ctx, w, h, (g) => {
      g.addColorStop(0, PAL.night);
      g.addColorStop(gy / h, PAL.nightMid);
      g.addColorStop(Math.min(0.99, gy / h + 0.01), "#d9cbb6");
      g.addColorStop(1, PAL.paperDeep);
    });
    stars(ctx, w, gy * 0.72, live, 28);
  } else if (dusk) {
    overscan(ctx, w, h, (g) => {
      g.addColorStop(0, "#f0b48a");
      g.addColorStop(gy / h, "#f6d7b4");
      g.addColorStop(1, PAL.paper);
    });
  } else if (dawn) {
    overscan(ctx, w, h, (g) => {
      g.addColorStop(0, "#f7d7b0");
      g.addColorStop(0.45, "#fbe7cf");
      g.addColorStop(1, PAL.paper);
    });
  } else {
    overscan(ctx, w, h, (g) => {
      g.addColorStop(0, "#f6f0e6");
      g.addColorStop(1, PAL.paper);
    });
    margin(ctx, h);
  }
  const ww = Math.min(w * 0.28, 240);
  const wh = ww * 0.8;
  const wx = w * 0.68;
  const wy = h * 0.1;
  ctx.save();
  ctx.fillStyle = night ? "#24344e" : dawn ? "#f8e2c0" : "#dce8ef";
  ctx.globalAlpha = revealAt(local, 0.2, 0.8);
  ctx.fillRect(wx, wy, ww, wh);
  ctx.restore();
  windowFrame(ctx, wx, wy, ww, wh, revealAt(local, 0.15, 1.2));
  if (night) moon(ctx, wx + ww * 0.7, wy + wh * 0.38, wh * 0.22, revealAt(local, 0.4, 0.8));

  const fly = tone === "dawn" ? clamp((local - 6) / 6) : clamp((local - 8) / 7);
  const bx = tone === "dawn" ? lerp(w + 30, wx + ww * 0.3, fly) : lerp(wx + 30, w + 40, fly);
  const by = wy + wh * 0.55 - Math.sin(fly * Math.PI) * 40;
  if (local < 6 || fly < 0.98) {
    bird(ctx, local < (tone === "dawn" ? 6 : 8) ? wx + ww * 0.3 : bx, local < 8 && tone !== "dawn" ? wy + wh * 0.62 : by, 0.85, live * 8, revealAt(local, 1, 0.8), fly * 0.2);
  }

  const desk = gy - 8;
  fillPoly(
    ctx,
    [
      [w * 0.08, desk],
      [w * 0.92, desk],
      [w + 10, h + 10],
      [-10, h + 10],
    ],
    night ? "#e6d7c2" : PAL.desk,
    1,
  );
  stroke(ctx, [[w * 0.06, desk], [w * 0.94, desk + 1]], { w: 2, seed: 11, reveal: revealAt(local, 0.2, 0.6) });

  blot(ctx, w * 0.22, desk - 10, 70, 40, PAL.sun, (0.18 + f.energy * 0.25) * revealAt(local, 0.4, 0.5));
  clock(ctx, w * 0.18, desk - 78, 26, live * 1.6, revealAt(local, 0.5, 0.8));

  const boxX = w * 0.42;
  frameRect(ctx, boxX, desk - 46, 78, 40, revealAt(local, 0.3, 0.7), PAL.ink, 1.8);
  ctx.save();
  ctx.globalAlpha = revealAt(local, 0.3, 0.7);
  ctx.fillStyle = PAL.wood;
  ctx.fillRect(boxX, desk - 46, 78, 40);
  ctx.restore();

  for (let i = 0; i < 5; i++) {
    const rv = revealAt(local, 0.6 + i * 0.55, 0.7);
    const bob = Math.sin(live * 0.8 + i) * 2;
    polaroid(ctx, boxX + 20 + (i - 2) * 28, desk - 78 - i * 6 + bob, (i - 2) * 0.08, 0.72, rv, () =>
      photoInner(ctx, i),
    );
  }

  const palm = revealAt(local, 13.5, 1.4);
  if (palm > 0.02) {
    openPalm(ctx, w * 0.62, h * 0.86, Math.min(1.3, w / 700), palm);
    heart(ctx, w * 0.62, h * 0.78, 0.7, PAL.rose, revealAt(local, 14.6, 0.8));
  }
}

function starsScene(f: Frame) {
  const { ctx, w, h, live, local } = f;
  const gy = groundY(h);
  const weary = smooth(clamp((local - 5.2) / 3));
  overscan(ctx, w, h, (g) => {
    g.addColorStop(0, lerpColor(weary, "#24344e", "#1a2030"));
    g.addColorStop(gy / h, lerpColor(weary, "#6d83a4", "#2a3344"));
    g.addColorStop(1, "#e7dcc8");
  });
  stars(ctx, w, gy * 0.8, live, Math.floor(lerp(40, 14, weary)));
  floor(ctx, w, h, gy, "#e5d8c4");
  const ps = peopleScale(h, gy);
  const jx = w * 0.58;
  const jy = gy - 70;
  oval(ctx, jx, jy, 34, 46, { w: 1.8, reveal: revealAt(local, 0.3, 0.8), seed: 12 });
  const count = Math.floor(lerp(14, 4, weary));
  for (let i = 0; i < count; i++) {
    const rise = weary * (20 + i * 6);
    const tw = 0.4 + Math.sin(live * 3 + i) * 0.4;
    starShape(ctx, jx + Math.sin(i) * 16, jy - 10 - (i % 5) * 8 - rise, 4, PAL.gold, tw * revealAt(local, 0.4 + i * 0.08, 0.4));
  }
  person(ctx, {
    x: w * 0.34,
    y: gy,
    s: ps,
    hair: "short",
    shirt: PAL.jacket,
    mood: weary > 0.55 ? "sad" : "soft",
    pose: weary > 0.45 ? "sit" : "stand",
    phase: live,
    reveal: revealAt(local, 0.2, 0.9),
  });
  person(ctx, {
    x: w * 0.5,
    y: gy,
    s: ps,
    flip: true,
    hair: "long",
    shirt: PAL.shirt,
    skirt: true,
    ribbon: PAL.sunset,
    mood: "smile",
    pose: "stand",
    phase: live,
    reveal: revealAt(local, 0.4, 0.8) * (1 - weary),
  });
  blot(ctx, w * 0.22, gy - 120, 40, 26, PAL.sun, (0.2 + f.energy * 0.2) * (1 - weary * 0.7));
}

function street(f: Frame) {
  const { ctx, w, h, live, local, span } = f;
  const gy = groundY(h);
  const u = clamp(local / span);
  const top = lerpColor(u, "#d7e8f2", "#f0b48c");
  const mid = lerpColor(u, "#f7efe4", "#f6c7a4");
  overscan(ctx, w, h, (g) => {
    g.addColorStop(0, top);
    g.addColorStop(gy / h, mid);
    g.addColorStop(1, "#e7d3b4");
  });
  sun(ctx, lerp(w * 0.78, w * 0.7, u), lerp(h * 0.16, gy - 20, u), 28, revealAt(local, 0.2, 0.6));
  hills(ctx, w, h, gy, [
    { y: gy - 30, amp: 18, color: "#e7cbb0", seed: 1 },
    { y: gy - 8, amp: 10, color: "#ecdcc6", seed: 2 },
  ]);
  floor(ctx, w, h, gy, "#e6d5bc");
  fallingLeaves(ctx, w, gy, live, 18);
  crowd(ctx, w, gy, live, revealAt(local, 0.3, 0.6));
  const ps = peopleScale(h, gy) * 0.92;
  const walk = smooth(clamp(local / (span * 0.8)));
  const x = lerp(w * 0.28, w * 0.46, walk);
  const dust = 1 - smooth(clamp(local / 3.2));
  for (let i = 0; i < 8; i++) {
    const a = live * 1.4 + i;
    blot(ctx, x + Math.cos(a) * 26 * dust, gy - 80 + Math.sin(a * 1.3) * 30, 3, 3, PAL.inkSoft, dust * 0.35);
  }
  person(ctx, {
    x,
    y: gy,
    s: ps,
    hair: "short",
    shirt: PAL.jacket,
    mood: "smile",
    pose: "walk",
    phase: live * 3,
    reveal: revealAt(local, 0.2, 1) * (1 - dust * 0.35),
  });
  person(ctx, {
    x: x + 62 * ps,
    y: gy,
    s: ps,
    flip: true,
    hair: "long",
    shirt: PAL.shirt,
    skirt: true,
    ribbon: PAL.sunset,
    mood: "smile",
    pose: "walk",
    phase: live * 3 + 0.4,
    reveal: revealAt(local, 0.45, 1),
  });
  stroke(ctx, [[x + 18 * ps, gy - 78], [x + 46 * ps, gy - 78]], {
    w: 1.5,
    color: PAL.inkSoft,
    reveal: revealAt(local, 1, 0.6),
    seed: 15,
  });
  pot(ctx, w * 0.82, gy - 6, smooth(clamp((local - 4.6) / 3.5)), revealAt(local, 4.2, 0.8));
}

function panel(
  ctx: Ctx,
  x: number,
  y: number,
  pw: number,
  ph: number,
  reveal: number,
  draw: () => void,
) {
  ctx.save();
  ctx.beginPath();
  ctx.rect(x, y, Math.max(0.01, pw), ph);
  ctx.clip();
  ctx.fillStyle = "#fbf6ec";
  ctx.globalAlpha = clamp(reveal);
  ctx.fillRect(x, y, pw, ph);
  ctx.globalAlpha = 1;
  if (reveal > 0.05) draw();
  ctx.restore();
  frameRect(ctx, x, y, pw, ph, reveal, PAL.ink, 1.6);
}

function knowyou(f: Frame) {
  const { ctx, w, h, live, local } = f;
  overscan(ctx, w, h, (g) => {
    g.addColorStop(0, "#f7f1e6");
    g.addColorStop(1, PAL.paper);
  });
  margin(ctx, h);
  const gap = Math.max(8, w * 0.02);
  const left = w * 0.08;
  const top = h * 0.06;
  const pw = (w * 0.84 - gap) / 2;
  const ph = (h * 0.58 - gap) / 2;
  const ps = Math.min(pw, ph) / 260;

  panel(ctx, left, top, pw, ph, revealAt(local, 0.1, 0.7), () => {
    for (let i = 0; i < 3; i++) {
      frameRect(ctx, left + 16 + i * 28, top + ph * 0.28, 22, 28, 1, PAL.inkSoft, 1);
      heart(ctx, left + 27 + i * 28, top + ph * 0.4, 0.28, i === 1 ? PAL.blue : PAL.rose, 1);
    }
    brush(ctx, "集邮", left + pw * 0.5, top + ph * 0.78, Math.max(16, pw * 0.12), PAL.inkSoft, 0.8);
  });

  panel(ctx, left + pw + gap, top, pw, ph, revealAt(local, 1.3, 0.7), () => {
    person(ctx, {
      x: left + pw + gap + pw * 0.55,
      y: top + ph * 0.86,
      s: ps * 1.15,
      hair: "long",
      shirt: PAL.shirt,
      skirt: true,
      ribbon: PAL.sunset,
      mood: local > 6 ? "shy" : "smile",
      pose: "wave",
      phase: live,
      reveal: 1,
    });
  });

  panel(ctx, left, top + ph + gap, pw, ph, revealAt(local, 3.1, 0.8), () => {
    ctx.fillStyle = local > 4.2 ? "#243044" : "#e7f0e4";
    ctx.fillRect(left, top + ph + gap, pw, ph);
    if (local > 4.2) moon(ctx, left + pw * 0.75, top + ph + gap + 28, 16, 1);
    bug(ctx, left + pw * 0.3, top + ph + gap + ph * 0.62, 1.4, 1);
    if (local > 4.4) ghost(ctx, left + pw * 0.62, top + ph + gap + ph * 0.55, 1.1, revealAt(local, 4.4, 0.6));
  });

  panel(ctx, left + pw + gap, top + ph + gap, pw, ph, revealAt(local, 6.2, 0.8), () => {
    const spin = live * 2;
    for (let i = 0; i < 3; i++) {
      const a = spin + i * 2;
      stroke(
        ctx,
        [
          [left + pw + gap + pw / 2, top + ph + gap + ph * 0.45],
          [left + pw + gap + pw / 2 + Math.cos(a) * 30, top + ph + gap + ph * 0.45 + Math.sin(a) * 12],
        ],
        { w: 1, color: PAL.faint, a: 0.7, passes: 1, seed: i },
      );
    }
    person(ctx, {
      x: left + pw + gap + pw * 0.5,
      y: top + ph + gap + ph * 0.88,
      s: ps * 0.85,
      hair: "long",
      shirt: PAL.gold,
      skirt: true,
      mood: "smile",
      pose: "wave",
      phase: live * 2,
      reveal: 1,
    });
  });

  const note = revealAt(local, 11.6, 1);
  if (note > 0.02) {
    letter(ctx, w / 2, h * 0.78, Math.min(w * 0.46, 280), 64, note);
  }
}

function dawn(f: Frame) {
  const { ctx, w, h, live, local, span } = f;
  const u = clamp(local / span);
  const gy = groundY(h);
  overscan(ctx, w, h, (g) => {
    g.addColorStop(0, lerpColor(u, "#141a28", "#f6c9a0"));
    g.addColorStop(gy / h, lerpColor(u, "#31405c", "#fbe6cf"));
    g.addColorStop(1, lerpColor(u, "#cbbca6", "#f3e2cc"));
  });
  if (u < 0.7) stars(ctx, w, gy, live, Math.floor(30 * (1 - u)));
  sun(ctx, w * 0.5, lerp(gy + 40, h * 0.28, smooth(clamp((u - 0.35) / 0.5))), 36, smooth(clamp((u - 0.3) / 0.4)));
  floor(ctx, w, h, gy, "#f0e2cc");
  const ps = peopleScale(h, gy) * 0.85;
  person(ctx, {
    x: w * 0.5,
    y: gy,
    s: ps,
    hair: "short",
    shirt: PAL.jacket,
    mood: u > 0.55 ? "soft" : "sleep",
    pose: u > 0.4 ? "stand" : "sit",
    phase: live,
    reveal: 1,
  });
  const blooms = 7;
  for (let i = 0; i < blooms; i++) {
    const open = smooth(clamp((local - 3.2 - i * 0.18) / 1.1));
    flower(ctx, w * 0.18 + i * ((w * 0.64) / blooms), gy, 0.9, open, i % 2 ? PAL.blush : PAL.white);
  }
}

function rainScene(f: Frame) {
  const { ctx, w, h, live, local } = f;
  const gy = groundY(h);
  const color = smooth(clamp((local - 2.6) / 3.2));
  overscan(ctx, w, h, (g) => {
    g.addColorStop(0, lerpColor(color, "#e7e4de", "#f3c3a6"));
    g.addColorStop(gy / h, lerpColor(color, "#f4efe8", "#f8dcc4"));
    g.addColorStop(1, "#e7dcc8");
  });
  if (color < 0.85) rain(ctx, w, gy, live, gy, (1 - color) * 0.7);
  sun(ctx, w * 0.8, h * 0.2, 26, color);
  hills(ctx, w, h, gy, [{ y: gy - 16, amp: 12, color: lerpColor(color, "#e5ddd2", "#f0cbb4"), seed: 2 }]);
  floor(ctx, w, h, gy, "#e4d6c2");
  const ps = peopleScale(h, gy) * 0.9;
  const x = w * 0.42;
  umbrella(ctx, x + 24 * ps, gy - 168 * ps, ps, color > 0.4 ? PAL.blue : "#d9d3c8", revealAt(local, 0.2, 0.8));
  person(ctx, {
    x,
    y: gy,
    s: ps,
    hair: "short",
    shirt: PAL.jacket,
    mood: color > 0.5 ? "smile" : "shy",
    pose: "stand",
    phase: live,
    reveal: revealAt(local, 0.3, 0.8),
  });
  person(ctx, {
    x: x + 58 * ps,
    y: gy,
    s: ps,
    flip: true,
    hair: "long",
    shirt: PAL.shirt,
    skirt: true,
    ribbon: PAL.sunset,
    mood: "smile",
    pose: "stand",
    phase: live,
    reveal: revealAt(local, 0.5, 0.8),
  });
  ctx.save();
  ctx.translate(w * 0.3, gy + 6);
  ctx.scale(1, 0.28);
  oval(ctx, 0, 0, 70, 70, { w: 1.3, color: PAL.blueDeep, a: 0.45, seed: 17 });
  ctx.restore();
  blot(ctx, w * 0.3, gy + 4, 54, 10, color > 0.3 ? PAL.sunset : PAL.blue, 0.25);

  const gift = revealAt(local, 7.4, 1);
  if (gift > 0.02) {
    polaroid(ctx, w * 0.78, gy - 70, -0.06, 1.15, gift, () => {
      ctx.fillStyle = "#d5e6ef";
      ctx.fillRect(-40, -52, 80, 68);
      person(ctx, {
        x: 0,
        y: 36,
        s: 0.42,
        hair: "long",
        shirt: PAL.blue,
        skirt: true,
        ribbon: PAL.blueDeep,
        mood: "smile",
        pose: "stand",
        reveal: 1,
      });
    });
    bow(ctx, w * 0.78, gy - 128, 0.7, gift);
  }
}

function room(f: Frame, cold: boolean) {
  const { ctx, w, h, live, local } = f;
  const gy = groundY(h);
  const night = cold || local > 5;
  overscan(ctx, w, h, (g) => {
    if (cold) {
      g.addColorStop(0, "#d5dde6");
      g.addColorStop(1, "#e4e0da");
    } else if (night) {
      g.addColorStop(0, "#2a3548");
      g.addColorStop(0.55, "#3d4d66");
      g.addColorStop(1, "#e6d8c4");
    } else {
      g.addColorStop(0, "#f6efe4");
      g.addColorStop(1, "#f3e6d2");
    }
  });
  const ww = Math.min(w * 0.22, 180);
  windowFrame(ctx, w * 0.12, h * 0.12, ww, ww * 0.75, 1);
  ctx.save();
  ctx.fillStyle = night && !cold ? "#1c2838" : "#d7e6ee";
  ctx.globalAlpha = 0.85;
  ctx.fillRect(w * 0.12, h * 0.12, ww, ww * 0.75);
  ctx.restore();
  floor(ctx, w, h, gy, cold ? "#ddd6cc" : "#eadcc6");
  const couchY = gy;
  const couchX = w * 0.5;
  const couchW = Math.min(w * 0.55, 460);
  ctx.save();
  ctx.fillStyle = cold ? "#8aa0b0" : "#c4785a";
  ctx.globalAlpha = 0.9;
  ctx.fillRect(couchX - couchW / 2, couchY - 48, couchW, 36);
  ctx.restore();
  frameRect(ctx, couchX - couchW / 2, couchY - 52, couchW, 40, 1, PAL.ink, 1.6);
  return { gy, couchX, couchW, ps: peopleScale(h, gy) * 0.78 };
}

function days(f: Frame) {
  const { ctx, w, live, local } = f;
  const { gy, couchX, ps } = room(f, false);
  const night = smooth(clamp((local - 4) / 3));
  person(ctx, {
    x: couchX - 50,
    y: gy - 8,
    s: ps,
    hair: "short",
    shirt: PAL.jacket,
    mood: "smile",
    pose: "sit",
    phase: live,
    reveal: 1,
  });
  person(ctx, {
    x: couchX + 46,
    y: gy - 8,
    s: ps,
    flip: true,
    hair: "long",
    shirt: PAL.shirt,
    skirt: true,
    ribbon: PAL.sunset,
    mood: "smile",
    pose: "sit",
    phase: live + 0.4,
    reveal: 1,
  });
  if (night < 0.5) blocks(ctx, w * 0.5 - 20, gy - 6, 1 - night);
  tv(ctx, w * 0.78, gy - 70, 1, live, night);
}

function rift(f: Frame) {
  const { ctx, w, h, live, local } = f;
  const { gy, couchX, ps } = room(f, true);
  const gap = lerp(40, 110, smooth(clamp(local / 6)));
  person(ctx, {
    x: couchX - gap,
    y: gy - 8,
    s: ps,
    hair: "short",
    shirt: "#9aa7b2",
    mood: "sad",
    pose: "apart",
    phase: live,
    reveal: 1,
  });
  person(ctx, {
    x: couchX + gap,
    y: gy - 8,
    s: ps,
    flip: true,
    hair: "long",
    shirt: "#b7c6d0",
    skirt: true,
    mood: "sad",
    pose: "apart",
    phase: live,
    reveal: 1,
  });
  phone(ctx, couchX - gap - 24, gy - 20, 1.1, true, revealAt(local, 0.4, 0.6));
  phone(ctx, couchX + gap + 10, gy - 18, 1.1, true, revealAt(local, 0.8, 0.6));
  const tearX = w * 0.5 + Math.sin(local) * 4;
  ctx.save();
  ctx.strokeStyle = "rgba(90,70,60,0.55)";
  ctx.lineWidth = 2;
  ctx.setLineDash([5, 6]);
  ctx.beginPath();
  ctx.moveTo(tearX, h * 0.08);
  for (let y = h * 0.08; y < h; y += 16) ctx.lineTo(tearX + Math.sin(y * 0.08) * 8, y);
  ctx.stroke();
  ctx.restore();
  const scar = revealAt(local, 5, 1.2);
  heart(ctx, w * 0.5, gy - 90, 0.85, PAL.rose, scar * 0.85);
  for (let i = -2; i <= 2; i++) {
    stroke(
      ctx,
      [
        [w * 0.5 - 10, gy - 90 + i * 8],
        [w * 0.5 + 10, gy - 90 + i * 8],
      ],
      { w: 1.2, color: PAL.gold, reveal: scar, seed: i + 4 },
    );
  }
}

function spark(f: Frame) {
  const { ctx, w, h, live, local } = f;
  const gy = groundY(h);
  overscan(ctx, w, h, (g) => {
    g.addColorStop(0, "#141a2a");
    g.addColorStop(gy / h, "#2c3c58");
    g.addColorStop(1, "#d9cbb8");
  });
  stars(ctx, w, gy * 0.75, live, 26);
  floor(ctx, w, h, gy, "#d7c9b4");
  stroke(ctx, [[w * 0.08, gy - 36], [w * 0.92, gy - 34]], { w: 2, color: PAL.inkSoft, seed: 4 });
  const ps = peopleScale(h, gy) * 0.82;
  person(ctx, {
    x: w * 0.4,
    y: gy,
    s: ps,
    hair: "short",
    shirt: PAL.jacket,
    mood: "soft",
    pose: "reach",
    phase: live,
    reveal: 1,
  });
  person(ctx, {
    x: w * 0.58,
    y: gy,
    s: ps,
    flip: true,
    hair: "long",
    shirt: PAL.shirt,
    skirt: true,
    ribbon: PAL.sunset,
    mood: "smile",
    pose: "stand",
    phase: live,
    reveal: 1,
  });
  const open = smooth(clamp((local - 1.2) / 3));
  paperFlower(ctx, w * 0.72, gy - 120, 1.1, open);
  firework(ctx, w * 0.3, h * 0.24, live, f.t - local + 6.4, PAL.sun);
  firework(ctx, w * 0.62, h * 0.18, live, f.t - local + 7.6, PAL.blush);
  firework(ctx, w * 0.78, h * 0.28, live, f.t - local + 8.7, PAL.blue);
  const joy = revealAt(local, 7.6, 1.2);
  for (let i = 0; i < 4; i++) {
    const u = smooth(clamp((joy * 1.2 - i * 0.08) ));
    scrap(ctx, lerp(w * (0.15 + i * 0.2), w * 0.42 + i * 36, u), lerp(h * 0.3, gy - 150, u), 42, (1 - u) * (i - 1.5) * 0.4, joy, PAL.gold, (c) => {
      starShape(c, 0, 2, 8, PAL.sun, 1);
    });
  }
}

function grow(f: Frame) {
  const { ctx, w, h, live, local, span } = f;
  const gy = groundY(h);
  const u = clamp(local / span);
  overscan(ctx, w, h, (g) => {
    g.addColorStop(0, "#f6d0a8");
    g.addColorStop(gy / h, "#f8e6cf");
    g.addColorStop(1, "#e7d5bc");
  });
  sun(ctx, w * 0.18, h * 0.16, 26, 1);
  hills(ctx, w, h, gy, [
    { y: gy - 70, amp: 26, color: "#c5b7a4", seed: 1 },
    { y: gy - 36, amp: 16, color: "#d9c3a4", seed: 2 },
  ]);
  const sea = smooth(clamp((u - 0.35) / 0.3));
  if (sea > 0.02) {
    ctx.save();
    ctx.globalAlpha = sea;
    ctx.fillStyle = PAL.sea;
    ctx.fillRect(w * 0.62, gy - 28, w * 0.4, 30);
    ctx.restore();
    for (let i = 0; i < 4; i++) {
      stroke(
        ctx,
        [
          [w * 0.64, gy - 16 + i * 6],
          [w * 0.78, gy - 20 + i * 6],
          [w * 0.95, gy - 14 + i * 6],
        ],
        { w: 1.3, color: "#d5e8ee", a: 0.7 * sea, seed: i },
      );
    }
  }
  floor(ctx, w, h, gy, "#e8d7be");
  fillPoly(
    ctx,
    [
      [w * 0.5, gy - 80],
      [w * 0.2, gy],
      [w * 0.85, gy],
    ],
    "#e7d3b2",
    0.65,
  );
  const growU = smooth(clamp((u - 0.05) / 0.7));
  const ps = peopleScale(h, gy) * lerp(0.48, 1, growU);
  const x = lerp(w * 0.34, w * 0.48, u);
  const pray = u > 0.72;
  person(ctx, {
    x: x - 28 * ps,
    y: gy,
    s: ps * 0.72,
    hair: "short",
    shirt: PAL.gold,
    mood: "smile",
    pose: "walk",
    phase: live * 3,
    reveal: 1 - smooth(clamp((u - 0.2) / 0.35)),
  });
  person(ctx, {
    x,
    y: gy,
    s: ps,
    hair: "short",
    shirt: PAL.jacket,
    mood: pray ? "soft" : "smile",
    pose: pray ? "pray" : "walk",
    phase: live * 2.4,
    reveal: revealAt(local, 0.2, 0.6),
  });
  person(ctx, {
    x: x + 54 * ps,
    y: gy,
    s: ps,
    flip: true,
    hair: "long",
    shirt: PAL.shirt,
    skirt: true,
    ribbon: PAL.sunset,
    mood: "smile",
    pose: pray ? "pray" : "walk",
    phase: live * 2.4 + 0.5,
    reveal: revealAt(local, 0.4, 0.6),
  });
  if (pray) starShape(ctx, w * 0.5, gy - 210 * ps, 10, PAL.gold, revealAt(local, span * 0.72, 1));
  bird(ctx, (live * 40) % (w + 40) - 20, h * 0.22, 0.7, live * 10, 0.8, -0.1);
}

function moonScene(f: Frame) {
  const { ctx, w, h, live, local } = f;
  const gy = groundY(h);
  overscan(ctx, w, h, (g) => {
    g.addColorStop(0, "#141a28");
    g.addColorStop(gy / h, "#2d3e5c");
    g.addColorStop(1, "#d5c8b4");
  });
  stars(ctx, w, gy * 0.55, live, 20);
  const u = clamp(local / f.span);
  const mr = lerp(h * 0.08, Math.min(h, w) * 0.26, smooth(u));
  const my = lerp(h * 0.22, h * 0.3, u);
  moon(ctx, w * 0.62, my, mr, 1);
  const asks = [0, 5.88, 11.88, 18.27];
  for (const a of asks) {
    const age = local - a;
    if (age > 0 && age < 2.4) {
      oval(ctx, w * 0.62, my, mr + age * 28, mr + age * 28, {
        w: 1.4,
        color: PAL.gold,
        a: 1 - age / 2.4,
        seed: a,
        passes: 1,
      });
    }
  }
  hills(ctx, w, h, gy, [{ y: gy - 10, amp: 14, color: "#cbbba6", seed: 3 }]);
  floor(ctx, w, h, gy, "#d8cbb8");
  const ps = peopleScale(h, gy) * 0.8;
  const smile = local > 2.2 && local < 8;
  person(ctx, {
    x: w * 0.32,
    y: gy,
    s: ps,
    hair: "short",
    shirt: PAL.jacket,
    mood: local > 16 ? "soft" : smile ? "smile" : "sad",
    pose: "sit",
    phase: live * 0.4,
    reveal: 1,
  });
  if (local > 7 && local < 16) {
    const loose = smooth(clamp((local - 8) / 4));
    kite(ctx, lerp(w * 0.48, w * 0.7, loose), lerp(gy - 150, h * 0.18, loose), 0.9, revealAt(local, 7, 0.6));
    stroke(
      ctx,
      [
        [w * 0.36, gy - 70],
        [lerp(w * 0.48, w * 0.7, loose), lerp(gy - 120, h * 0.24, loose)],
      ],
      { w: 1.1, color: PAL.faint, a: 1 - loose * 0.7, seed: 19 },
    );
  }
  if (local > 22) {
    const wr = revealAt(local, 23.6, 1.4);
    ctx.save();
    ctx.beginPath();
    ctx.rect(w * 0.62 - mr, my - 10, mr * 2 * wr, 48);
    ctx.clip();
    brush(ctx, "要爱自己啊", w * 0.62, my, Math.max(18, mr * 0.28), PAL.inkSoft, 0.85);
    ctx.restore();
  }
}

const SCRAPS: { tint: string; mark: (ctx: Ctx) => void }[] = [
  { tint: "#d5e4ee", mark: (c) => rain(c, 80, 70, 1, 60, 0.5) },
  { tint: "#f6e7c4", mark: (c) => bird(c, 0, 4, 1.1, 1, 1) },
  { tint: "#e5f0e4", mark: (c) => flower(c, 0, 6, 0.8, 1, PAL.blush) },
  { tint: "#f6d0b0", mark: (c) => sun(c, 0, 0, 12, 1) },
  { tint: "#d5e6ef", mark: (c) => heart(c, 0, 2, 0.7, PAL.blue, 1) },
  { tint: "#cfe0e8", mark: (c) => { c.fillStyle = PAL.sea; c.fillRect(-20, 4, 40, 16); } },
  { tint: "#e7e0d4", mark: (c) => moon(c, 0, 0, 14, 1) },
  { tint: "#243044", mark: (c) => starShape(c, 0, 0, 10, PAL.gold, 1) },
  { tint: "#f8e4e0", mark: (c) => heart(c, 0, 2, 0.85, PAL.rose, 1) },
];

function pieces(f: Frame, force?: number) {
  const { ctx, w, h, live, local, span } = f;
  const gy = groundY(h);
  overscan(ctx, w, h, (g) => {
    g.addColorStop(0, "#f3c7a4");
    g.addColorStop(0.45, "#f8e6d2");
    g.addColorStop(1, PAL.paper);
  });
  sun(ctx, w * 0.14, h * 0.16, 22, 0.9);
  hills(ctx, w, h, gy, [{ y: gy - 8, amp: 12, color: "#f0dcc4", seed: 2 }]);
  floor(ctx, w, h, gy, "#eddcc4");
  const u = force ?? smooth(clamp((local - 4) / (span * 0.86)));
  const ps = peopleScale(h, gy) * 0.72;
  person(ctx, {
    x: w * 0.16,
    y: gy,
    s: ps,
    hair: "short",
    shirt: PAL.jacket,
    mood: u < 0.35 ? "sad" : "soft",
    pose: u > 0.72 ? "reach" : "stand",
    phase: live * 0.5,
    reveal: 1,
  });
  const size = Math.min(w, h) * 0.13;
  const gap = size * 0.12;
  const gridW = 3 * size + 2 * gap;
  const x0 = w * 0.58 - gridW / 2 + size / 2;
  const y0 = h * 0.34 - gridW / 2 + size / 2;
  const palm = revealAt(u * span, span * 0.62, span * 0.2);
  if (force === 1 || u > 0.62) {
    openPalm(ctx, w * 0.58, h * 0.86, Math.min(1.6, w / 520), force === 1 ? 1 : palm);
  }
  SCRAPS.forEach((sc, i) => {
    const col = i % 3;
    const row = Math.floor(i / 3);
    const tx = x0 + col * (size + gap);
    const ty = y0 + row * (size + gap) + (1 - (force ?? u)) * 0;
    const ang = i * 2.399;
    const sx = w * 0.5 + Math.cos(ang) * w * 0.36;
    const sy = h * 0.4 + Math.sin(ang * 1.2) * h * 0.26;
    const p = force ?? u;
    const x = lerp(sx, tx, p) + Math.sin(live * 0.7 + i) * (1 - p) * 8;
    const y = lerp(sy, ty, p) + Math.cos(live * 0.6 + i) * (1 - p) * 6;
    const rot = lerp((i - 4) * 0.35, 0, p);
    scrap(ctx, x, y, size, rot, revealAt(local, i * 0.12, 0.5), sc.tint, () => sc.mark(ctx));
  });
  if ((force ?? u) > 0.92) bow(ctx, w * 0.58, y0 - size * 0.85, 1, force === 1 ? 1 : revealAt(local, span * 0.9, 0.8));
  const pulse = Math.exp(-((local - (span - 3)) ** 2) / 2.2);
  if (pulse > 0.05 && force == null) blot(ctx, w * 0.58, h * 0.36, 180, 140, PAL.sun, pulse * 0.35);
}

function coda(f: Frame) {
  pieces({ ...f, local: f.span }, 1);
  const { ctx, w, h, live } = f;
  for (let i = 0; i < 14; i++) {
    const x = (i * 97 + Math.sin(live * 0.4 + i) * 20) % w;
    const y = (h * 0.15 + ((i * 53 + live * 12) % (h * 0.5)));
    blot(ctx, x, y, 2.2, 2.2, PAL.gold, 0.35 + Math.sin(live * 2 + i) * 0.25);
  }
  brush(ctx, "给你", w * 0.58, h * 0.7, Math.min(42, w * 0.05), PAL.inkSoft, 0.75);
}

function lerpColor(t: number, a: string, b: string) {
  const pa = hex(a);
  const pb = hex(b);
  const r = Math.round(lerp(pa[0], pb[0], t));
  const g = Math.round(lerp(pa[1], pb[1], t));
  const bl = Math.round(lerp(pa[2], pb[2], t));
  return `rgb(${r},${g},${bl})`;
}

function hex(c: string): [number, number, number] {
  const h = c.replace("#", "");
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}

function drawCue(ctx: Ctx, cue: Cue, index: number, w: number, h: number, t: number, live: number, energy: number, poster: boolean) {
  const next = CUES[index + 1]?.t0 ?? t + 40;
  const f: Frame = {
    ctx,
    w,
    h,
    t,
    live,
    local: t - cue.t0,
    span: next - cue.t0,
    energy,
    poster,
    tone: cue.tone ?? "day",
  };
  switch (cue.id) {
    case "intro":
      intro(f);
      break;
    case "keepsake":
      keepsake(f);
      break;
    case "stars":
      starsScene(f);
      break;
    case "street":
      street(f);
      break;
    case "knowyou":
      knowyou(f);
      break;
    case "dawn":
      dawn(f);
      break;
    case "rain":
      rainScene(f);
      break;
    case "days":
      days(f);
      break;
    case "rift":
      rift(f);
      break;
    case "spark":
      spark(f);
      break;
    case "grow":
      grow(f);
      break;
    case "moon":
      moonScene(f);
      break;
    case "pieces":
      pieces(f);
      break;
    case "coda":
      coda(f);
      break;
  }
}

function findCue(t: number) {
  let index = 0;
  for (let i = 0; i < CUES.length; i++) if (CUES[i].t0 <= t) index = i;
  return index;
}

function clipWipe(ctx: Ctx, w: number, h: number, u: number, live: number) {
  const edge = -30 + u * (w + 70);
  ctx.beginPath();
  ctx.moveTo(-60, -60);
  ctx.lineTo(edge, -60);
  for (let y = -40; y <= h + 60; y += 14) {
    ctx.lineTo(edge + Math.sin(y * 0.045 + live) * 9, y);
  }
  ctx.lineTo(-60, h + 60);
  ctx.closePath();
  ctx.clip();
}

export function paint(
  ctx: Ctx,
  w: number,
  h: number,
  t: number,
  live: number,
  energy: number,
  poster = false,
) {
  if (w < 8 || h < 8) return;
  setFrameLive(live);
  const index = findCue(t);
  const cue = CUES[index];
  const prev = index > 0 ? CUES[index - 1] : null;
  const into = t - cue.t0;
  const wipeDur = 1.05;
  ctx.save();
  ctx.beginPath();
  ctx.rect(0, 0, w, h);
  ctx.clip();
  const dx = Math.sin(live * 0.2) * 5;
  const dy = Math.cos(live * 0.16) * 3;
  ctx.translate(dx, dy);
  if (prev && into >= 0 && into < wipeDur) {
    drawCue(ctx, prev, index - 1, w, h, t, live, energy, false);
    ctx.save();
    clipWipe(ctx, w, h, into / wipeDur, live);
    drawCue(ctx, cue, index, w, h, t, live, energy, poster);
    ctx.restore();
    const edge = -30 + (into / wipeDur) * (w + 70);
    stroke(
      ctx,
      Array.from({ length: 18 }, (_, i) => {
        const y = (i / 17) * h;
        return [edge + Math.sin(y * 0.045 + live) * 9, y] as [number, number];
      }),
      { w: 1.4, color: PAL.inkSoft, a: 0.45, passes: 1, seed: 7 },
    );
  } else {
    drawCue(ctx, cue, index, w, h, t, live, energy, poster);
  }
  ctx.restore();
  const pattern = paperGrain(ctx);
  if (pattern) {
    ctx.save();
    ctx.globalAlpha = 0.2;
    ctx.fillStyle = pattern;
    ctx.fillRect(0, 0, w, h);
    ctx.restore();
  }
  vignette(ctx, w, h);
}
