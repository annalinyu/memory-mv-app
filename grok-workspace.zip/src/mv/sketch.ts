export type Ctx = CanvasRenderingContext2D;
export type Pt = [number, number];

export const PAL = {
  paper: "#f4ebda",
  paperDeep: "#e7d8c0",
  desk: "#efe2cc",
  ink: "#2c261f",
  inkSoft: "#6d6256",
  faint: "#b5a690",
  skin: "#f0cbb4",
  skinDeep: "#e2b496",
  sunset: "#e07a4c",
  sun: "#f2b15a",
  blush: "#e7a394",
  leaf: "#7e9164",
  leafDeep: "#4e6844",
  sky: "#d7e6ee",
  dusk: "#f3c2a4",
  night: "#1b2436",
  nightMid: "#31425f",
  blue: "#6e92a6",
  blueDeep: "#3e6278",
  sea: "#3f6e82",
  gold: "#d7b57a",
  white: "#fffaf3",
  rose: "#c96b6b",
  jacket: "#c4785a",
  pants: "#4d463f",
  shirt: "#8fb4c6",
  wood: "#e4c89a",
};

let frameLive = 0;

export function setFrameLive(t: number) {
  frameLive = t;
}

export function clamp(v: number, a = 0, b = 1) {
  return Math.max(a, Math.min(b, v));
}

export function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

export function smooth(t: number) {
  const x = clamp(t);
  return x * x * (3 - 2 * x);
}

export function revealAt(local: number, delay: number, dur = 0.75) {
  return smooth((local - delay) / dur);
}

export function qbez(a: Pt, b: Pt, c: Pt, n = 8): Pt[] {
  const out: Pt[] = [];
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    const u = 1 - t;
    out.push([
      u * u * a[0] + 2 * u * t * b[0] + t * t * c[0],
      u * u * a[1] + 2 * u * t * b[1] + t * t * c[1],
    ]);
  }
  return out;
}

type StrokeOpt = {
  w?: number;
  color?: string;
  a?: number;
  reveal?: number;
  passes?: number;
  seed?: number;
  steady?: boolean;
};

export function stroke(ctx: Ctx, pts: Pt[], opt: StrokeOpt = {}) {
  const reveal = opt.reveal ?? 1;
  if (reveal <= 0.01 || pts.length < 2) return;
  const color = opt.color ?? PAL.ink;
  const width = opt.w ?? 2;
  const passes = opt.passes ?? 2;
  const seed = opt.seed ?? pts[0][0] * 0.013 + pts[0][1] * 0.017;
  const steady = opt.steady ?? false;
  const q = Math.floor(frameLive * 8);
  const boilX = steady ? 0 : Math.sin(q * 1.7 + seed * 3) * width * 0.16;
  const boilY = steady ? 0 : Math.cos(q * 1.3 + seed * 2) * width * 0.16;
  const wobble = steady ? width * 0.045 : width * 0.16;
  const maxSeg = (pts.length - 1) * reveal;
  ctx.save();
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.strokeStyle = color;
  ctx.globalAlpha *= opt.a ?? 1;
  for (let p = 0; p < passes; p++) {
    ctx.lineWidth = width * (p === 0 ? 1 : 0.42);
    ctx.beginPath();
    const jx = (steady ? 0 : Math.sin(seed * 4 + p * 2.1) * width * 0.22) + boilX;
    const jy = (steady ? 0 : Math.cos(seed * 3 + p * 1.7) * width * 0.22) + boilY;
    let started = false;
    const last = Math.min(pts.length - 1, Math.ceil(maxSeg));
    for (let i = 0; i <= last; i++) {
      const wob = Math.sin(i * 1.7 + seed + p) * wobble;
      let x = pts[i][0] + jx + wob;
      let y = pts[i][1] + jy + Math.cos(i * 1.3 + seed) * wobble;
      if (i > 0 && i > maxSeg) {
        const f = clamp(maxSeg - (i - 1));
        const px = pts[i - 1][0] + jx;
        const py = pts[i - 1][1] + jy;
        x = px + (x - px) * f;
        y = py + (y - py) * f;
      }
      if (!started) {
        ctx.moveTo(x, y);
        started = true;
      } else ctx.lineTo(x, y);
      if (i > maxSeg) break;
    }
    ctx.stroke();
  }
  ctx.restore();
}

export function fillPoly(ctx: Ctx, pts: Pt[], color: string, alpha = 1) {
  if (pts.length < 3 || alpha <= 0.01) return;
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

export function blot(ctx: Ctx, x: number, y: number, rx: number, ry: number, color: string, alpha = 1) {
  if (alpha <= 0.01 || rx <= 0 || ry <= 0) return;
  ctx.save();
  ctx.translate(x, y);
  const g = ctx.createRadialGradient(-rx * 0.15, -ry * 0.2, Math.min(rx, ry) * 0.08, 0, 0, Math.max(rx, ry));
  g.addColorStop(0, color);
  g.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = g;
  ctx.globalAlpha *= alpha;
  ctx.beginPath();
  ctx.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

export function oval(ctx: Ctx, x: number, y: number, rx: number, ry: number, opt: StrokeOpt = {}) {
  const n = 16;
  const pts: Pt[] = [];
  for (let i = 0; i <= n; i++) {
    const a = (i / n) * Math.PI * 2;
    pts.push([x + Math.cos(a) * rx, y + Math.sin(a) * ry]);
  }
  stroke(ctx, pts, opt);
}

export function frameRect(
  ctx: Ctx,
  x: number,
  y: number,
  w: number,
  h: number,
  reveal: number,
  color = PAL.ink,
  lw = 2.2,
) {
  const segs: Pt[][] = [
    [
      [x, y],
      [x + w, y],
    ],
    [
      [x + w, y],
      [x + w, y + h],
    ],
    [
      [x + w, y + h],
      [x, y + h],
    ],
    [
      [x, y + h],
      [x, y],
    ],
  ];
  segs.forEach((seg, i) => {
    stroke(ctx, seg, { w: lw, color, reveal: clamp(reveal * 4 - i), seed: i + x * 0.01 });
  });
}

export function brush(
  ctx: Ctx,
  text: string,
  x: number,
  y: number,
  size: number,
  color: string,
  alpha = 1,
) {
  if (alpha <= 0.01 || !text) return;
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.fillStyle = color;
  ctx.font = `${size}px "Ma Shan Zheng", "WenQuanYi Zen Hei", serif`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(text, x, y);
  ctx.restore();
}

let grain: CanvasPattern | null = null;

export function paperGrain(ctx: Ctx) {
  if (grain) return grain;
  const c = document.createElement("canvas");
  c.width = 180;
  c.height = 180;
  const g = c.getContext("2d");
  if (!g) return null;
  const img = g.createImageData(180, 180);
  for (let i = 0; i < img.data.length; i += 4) {
    const n = Math.random();
    img.data[i] = 70;
    img.data[i + 1] = 52;
    img.data[i + 2] = 34;
    img.data[i + 3] = n > 0.78 ? Math.floor((n - 0.78) * 220) : 0;
  }
  g.putImageData(img, 0, 0);
  grain = ctx.createPattern(c, "repeat");
  return grain;
}

export function vignette(ctx: Ctx, w: number, h: number) {
  const vg = ctx.createRadialGradient(
    w / 2,
    h / 2,
    Math.min(w, h) * 0.42,
    w / 2,
    h * 0.46,
    Math.max(w, h) * 0.72,
  );
  vg.addColorStop(0, "rgba(0,0,0,0)");
  vg.addColorStop(1, "rgba(48,32,20,0.2)");
  ctx.fillStyle = vg;
  ctx.fillRect(0, 0, w, h);
}
